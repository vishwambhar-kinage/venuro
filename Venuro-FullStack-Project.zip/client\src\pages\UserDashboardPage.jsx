import React, { useState, useEffect } from 'react';
import { 
  Ticket, 
  Wallet, 
  Calendar, 
  Clock, 
  MapPin, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  ChevronRight, 
  Printer, 
  Sparkles,
  RefreshCw
} from 'lucide-react';
import { bookingAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { DigitalTicketModal } from '../components/DigitalTicketModal';

export const UserDashboardPage = () => {
  const { user, refreshUser } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [cancelModalBooking, setCancelModalBooking] = useState(null);
  const [cancelling, setCancelling] = useState(false);
  const [cancelMessage, setCancelMessage] = useState('');

  useEffect(() => {
    fetchUserBookings();
  }, []);

  const fetchUserBookings = async () => {
    setLoading(true);
    try {
      const res = await bookingAPI.getMyBookings();
      if (res.success) {
        setBookings(res.bookings || []);
      }
    } catch (err) {
      console.error('Failed to fetch user bookings:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmCancel = async () => {
    if (!cancelModalBooking) return;
    setCancelling(true);
    setCancelMessage('');

    try {
      const res = await bookingAPI.cancelBooking(cancelModalBooking._id, 'Customer cancellation via dashboard');
      if (res.success) {
        setCancelMessage(res.message);
        await refreshUser();
        await fetchUserBookings();
        setTimeout(() => {
          setCancelModalBooking(null);
          setCancelMessage('');
        }, 1800);
      }
    } catch (err) {
      setCancelMessage(`Error: ${err.message}`);
    } finally {
      setCancelling(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 pb-20">
      {/* Profile Overview Card */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <img
            src={user?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.name}`}
            alt={user?.name}
            className="w-16 h-16 rounded-2xl object-cover border-2 border-fuchsia-500/40 bg-slate-900 shadow-xl"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-white font-['Space_Grotesk']">{user?.name}</h1>
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-fuchsia-500/20 text-fuchsia-300 border border-fuchsia-500/30">
                {user?.role}
              </span>
            </div>
            <p className="text-xs text-slate-400">{user?.email}</p>
            <div className="flex flex-wrap gap-1.5 mt-2">
              {user?.preferences?.map((pref, idx) => (
                <span key={idx} className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800">
                  {pref}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Venuro Wallet Balance Card */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-tr from-fuchsia-950/70 via-purple-950/60 to-slate-900 border border-fuchsia-500/30 shadow-xl flex items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-fuchsia-600/30 border border-fuchsia-500/40">
              <Wallet className="w-6 h-6 text-fuchsia-300" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Venuro Wallet</span>
              <span className="text-2xl font-black text-emerald-400 font-mono">₹{user?.walletBalance || 0}</span>
            </div>
          </div>
          <div className="text-right text-[10px] text-slate-400 max-w-[120px]">
            Instant automated refund credits & express checkout
          </div>
        </div>
      </div>

      {/* Bookings Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-lg font-bold text-white font-['Space_Grotesk']">My Bookings & Verified QR Passes</h2>
            <p className="text-xs text-slate-400">View digital passes, download tickets, or process instant cancellations</p>
          </div>
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-slate-900 text-slate-300 border border-slate-800">
            {bookings.length} Total Bookings
          </span>
        </div>

        {loading ? (
          <div className="py-20 flex flex-col items-center justify-center text-slate-400 space-y-3">
            <RefreshCw className="w-8 h-8 text-fuchsia-400 animate-spin" />
            <p className="text-xs font-semibold">Retrieving your passes...</p>
          </div>
        ) : bookings.length === 0 ? (
          <div className="glass-panel p-12 rounded-3xl text-center max-w-md mx-auto space-y-4">
            <Ticket className="w-12 h-12 text-slate-600 mx-auto" />
            <h3 className="text-base font-bold text-white">No active bookings yet</h3>
            <p className="text-xs text-slate-400">
              Explore trending concerts, movies, and live sports to experience real-time seat reservation.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {bookings.map((booking) => {
              const isCancelled = booking.bookingStatus === 'CANCELLED';

              return (
                <div
                  key={booking._id}
                  className={`relative rounded-3xl overflow-hidden glass-card border transition-all ${
                    isCancelled ? 'border-rose-900/40 opacity-70' : 'border-slate-800 hover:border-fuchsia-500/40'
                  }`}
                >
                  <div className="p-5 sm:p-6 space-y-4">
                    {/* Header: Title & Status */}
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border ${
                          isCancelled
                            ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                            : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                        }`}>
                          {booking.bookingStatus}
                        </span>
                        <h3 className="font-extrabold text-base text-white mt-1.5 line-clamp-1">
                          {booking.event?.title || 'Entertainment Event'}
                        </h3>
                        <p className="text-xs text-slate-400 truncate">
                          {booking.event?.venueName || 'Venuro Venue'}
                        </p>
                      </div>

                      {/* QR Thumbnail */}
                      {booking.qrCodeImage && (
                        <div
                          onClick={() => setSelectedTicket(booking)}
                          className="p-1.5 bg-white rounded-xl shadow-md cursor-pointer hover:scale-105 transition-transform shrink-0"
                          title="Click to expand QR Pass"
                        >
                          <img
                            src={booking.qrCodeImage}
                            alt="Ticket QR"
                            className="w-14 h-14 object-contain"
                          />
                        </div>
                      )}
                    </div>

                    {/* Booking Meta */}
                    <div className="grid grid-cols-2 gap-2 p-3 rounded-2xl bg-slate-950/80 border border-slate-900 text-xs">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-500 block">Date & Time</span>
                        <span className="font-semibold text-slate-200">
                          {booking.show?.date} @ {booking.show?.startTime}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-500 block">Seats ({booking.seats?.length})</span>
                        <span className="font-bold text-fuchsia-400 font-mono">
                          {booking.seats?.map(s => s.id).join(', ')}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-500 block">Booking No.</span>
                        <span className="font-mono text-slate-300 text-[11px] truncate block">
                          {booking.bookingNumber}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-500 block">Total Paid</span>
                        <span className="font-bold text-slate-200 font-mono">
                          ₹{booking.finalAmount}
                        </span>
                      </div>
                    </div>

                    {/* Cancellation details if cancelled */}
                    {isCancelled && (
                      <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-900/60 text-xs text-rose-300 space-y-0.5">
                        <p className="font-bold">Refund Processed: ₹{booking.refundAmount}</p>
                        <p className="text-[11px] text-rose-400">Credited to Venuro Wallet balance.</p>
                      </div>
                    )}

                    {/* Actions */}
                    <div className="pt-2 flex items-center justify-between gap-2 border-t border-slate-800/80">
                      <button
                        onClick={() => setSelectedTicket(booking)}
                        className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all"
                      >
                        <Ticket className="w-3.5 h-3.5 text-fuchsia-400" />
                        <span>View Pass</span>
                      </button>

                      {!isCancelled && (
                        <button
                          onClick={() => setCancelModalBooking(booking)}
                          className="px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 text-xs font-bold transition-all"
                        >
                          Cancel & Refund
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Cancellation Confirmation Modal */}
      {cancelModalBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-md glass-dropdown rounded-3xl border border-rose-500/40 shadow-2xl p-6 space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <div>
                <h3 className="font-bold text-white text-base">Cancel Booking</h3>
                <p className="text-xs text-slate-400">{cancelModalBooking.event?.title}</p>
              </div>
            </div>

            {cancelMessage ? (
              <div className="p-4 rounded-2xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-200 text-xs font-semibold text-center">
                {cancelMessage}
              </div>
            ) : (
              <>
                <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 space-y-2">
                  <p className="font-semibold text-slate-200">Refund Policy Breakdown:</p>
                  <ul className="space-y-1 text-[11px] text-slate-400">
                    <li>• &gt; 24 hrs before show: <strong>100% full refund</strong></li>
                    <li>• 4 - 24 hrs before show: <strong>70% refund</strong></li>
                    <li>• &lt; 4 hrs before show: <strong>Non-refundable</strong></li>
                  </ul>
                  <div className="pt-2 border-t border-slate-800 flex justify-between font-bold text-slate-200">
                    <span>Original Amount Paid:</span>
                    <span className="font-mono text-fuchsia-400">₹{cancelModalBooking.finalAmount}</span>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    onClick={() => setCancelModalBooking(null)}
                    disabled={cancelling}
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold"
                  >
                    Keep Booking
                  </button>
                  <button
                    onClick={handleConfirmCancel}
                    disabled={cancelling}
                    className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-lg shadow-rose-600/30 flex items-center gap-1.5"
                  >
                    {cancelling ? 'Cancelling...' : 'Confirm Cancellation'}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Digital Pass Modal */}
      {selectedTicket && (
        <DigitalTicketModal
          isOpen={!!selectedTicket}
          onClose={() => setSelectedTicket(null)}
          booking={selectedTicket}
        />
      )}
    </div>
  );
};
