import React, { useState, useEffect } from 'react';
import { Lock, Check, Timer, AlertTriangle, ShieldCheck, Armchair } from 'lucide-react';

export const SeatMatrix = ({
  show,
  event,
  selectedSeats,
  onToggleSeat,
  isLockedByMe,
  lockSecondsRemaining,
  onProceedCheckout,
  lockingLoading
}) => {
  const formatTime = (secs) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const getTierBadge = (tier) => {
    switch (tier) {
      case 'VIP':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      case 'PREMIUM':
        return 'bg-purple-500/20 text-purple-300 border-purple-500/30';
      case 'STANDARD':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
      default:
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
    }
  };

  const calculateSubtotal = () => {
    return selectedSeats.reduce((sum, seat) => sum + seat.price, 0);
  };

  return (
    <div className="space-y-8">
      {/* Active Redis Lock Countdown Banner */}
      {isLockedByMe && lockSecondsRemaining > 0 && (
        <div className={`p-4 rounded-2xl border flex items-center justify-between transition-all animate-pulse ${
          lockSecondsRemaining < 60
            ? 'bg-rose-950/70 border-rose-500/50 text-rose-200'
            : 'bg-fuchsia-950/70 border-fuchsia-500/50 text-fuchsia-200'
        }`}>
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-fuchsia-600/30 border border-fuchsia-500/40">
              <Timer className="w-5 h-5 text-fuchsia-400" />
            </div>
            <div>
              <p className="font-bold text-sm">Redis Seat Lock Active!</p>
              <p className="text-xs text-slate-300">
                Your seats are held exclusively. Complete checkout before the timer expires.
              </p>
            </div>
          </div>
          <div className="text-right">
            <span className="font-mono text-xl sm:text-2xl font-black text-white">
              {formatTime(lockSecondsRemaining)}
            </span>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Remaining</span>
          </div>
        </div>
      )}

      {/* Screen / Stage Curve */}
      <div className="relative pt-6 pb-2 text-center">
        <div className="max-w-2xl mx-auto h-3 cinema-screen rounded-t-full shadow-lg" />
        <p className="text-[11px] font-bold uppercase tracking-[0.25em] text-slate-400 mt-3 flex items-center justify-center gap-2">
          <span>SCREEN / STAGE THIS WAY</span>
        </p>
      </div>

      {/* Seating Matrix Grid */}
      <div className="overflow-x-auto pb-4">
        <div className="min-w-[680px] max-w-4xl mx-auto space-y-3">
          {show.seatGrid.map((rowSeats, rIdx) => {
            const rowLetter = rowSeats[0]?.row || '';
            const rowTier = rowSeats[0]?.tier || 'STANDARD';
            const rowPrice = rowSeats[0]?.price || 500;

            return (
              <div key={rIdx} className="flex items-center justify-center gap-2">
                {/* Row Letter & Tier label */}
                <div className="w-16 flex items-center justify-between text-xs pr-2">
                  <span className="font-bold text-slate-400 font-mono">{rowLetter}</span>
                  <span className={`text-[9px] px-1.5 py-0.5 rounded border font-semibold ${getTierBadge(rowTier)}`}>
                    ₹{rowPrice}
                  </span>
                </div>

                {/* Seats in Row */}
                <div className="flex items-center gap-1.5 sm:gap-2">
                  {rowSeats.map((seat) => {
                    const isSelected = selectedSeats.some((s) => s.id === seat.id);
                    const isBooked = seat.status === 'booked';
                    const isLockedByOthers = seat.status === 'locked' && !seat.isLockedByMe;

                    let seatStyle = 'bg-slate-800 border-slate-700 text-slate-300 hover:border-fuchsia-400 hover:bg-slate-700 cursor-pointer';

                    if (isBooked) {
                      seatStyle = 'bg-slate-950/70 border-slate-900 text-slate-700 cursor-not-allowed opacity-40';
                    } else if (isLockedByOthers) {
                      seatStyle = 'bg-amber-950/70 border-amber-600/60 text-amber-400 cursor-not-allowed animate-pulse';
                    } else if (isSelected) {
                      seatStyle = 'bg-fuchsia-600 border-fuchsia-400 text-white shadow-lg shadow-fuchsia-600/50 scale-105';
                    }

                    return (
                      <button
                        key={seat.id}
                        onClick={() => !isBooked && !isLockedByOthers && onToggleSeat(seat)}
                        disabled={isBooked || isLockedByOthers}
                        title={`Seat ${seat.id} (${seat.tier}) - ₹${seat.price}`}
                        className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg border text-[10px] font-bold flex items-center justify-center transition-all duration-150 ${seatStyle}`}
                      >
                        {isBooked ? (
                          <XIcon className="w-3 h-3 text-slate-600" />
                        ) : isLockedByOthers ? (
                          <Lock className="w-3 h-3 text-amber-400" />
                        ) : isSelected ? (
                          <Check className="w-3.5 h-3.5" />
                        ) : (
                          seat.col
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Legend */}
      <div className="glass-panel p-4 rounded-2xl flex flex-wrap items-center justify-center gap-6 text-xs text-slate-300">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-md bg-slate-800 border border-slate-700" />
          <span>Available</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-md bg-fuchsia-600 border border-fuchsia-400" />
          <span className="font-semibold text-fuchsia-400">Selected</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-md bg-amber-950/70 border border-amber-600/60 flex items-center justify-center">
            <Lock className="w-2.5 h-2.5 text-amber-400" />
          </div>
          <span>Locked by others (5-min TTL)</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-md bg-slate-950 border border-slate-900 opacity-50 flex items-center justify-center">
            <XIcon className="w-2.5 h-2.5 text-slate-600" />
          </div>
          <span>Booked</span>
        </div>
      </div>

      {/* Bottom Sticky Action Bar */}
      {selectedSeats.length > 0 && (
        <div className="sticky bottom-4 z-30 glass-dropdown p-4 sm:p-5 rounded-2xl border border-fuchsia-500/40 shadow-2xl shadow-fuchsia-950 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase tracking-wider text-slate-400 font-bold">Selected Seats</span>
              <div className="flex flex-wrap gap-1">
                {selectedSeats.map((s) => (
                  <span key={s.id} className="text-xs font-bold px-2 py-0.5 rounded-md bg-fuchsia-500/20 text-fuchsia-300 border border-fuchsia-500/30">
                    {s.id}
                  </span>
                ))}
              </div>
            </div>
            <p className="text-xl sm:text-2xl font-black text-white mt-1">
              ₹{calculateSubtotal()} <span className="text-xs text-slate-400 font-normal">+ taxes & fees</span>
            </p>
          </div>

          <button
            onClick={onProceedCheckout}
            disabled={lockingLoading}
            className="px-6 py-3 rounded-xl font-bold text-sm bg-gradient-to-r from-fuchsia-600 to-indigo-600 hover:from-fuchsia-500 hover:to-indigo-500 text-white shadow-xl shadow-fuchsia-600/30 flex items-center gap-2 transition-all disabled:opacity-50"
          >
            {lockingLoading ? (
              <span>Acquiring Redis Lock...</span>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4" />
                <span>Lock Seats & Checkout ({selectedSeats.length})</span>
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
};

const XIcon = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <line x1="18" y1="6" x2="6" y2="18"></line>
    <line x1="6" y1="6" x2="18" y2="18"></line>
  </svg>
);
