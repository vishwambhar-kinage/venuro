import express from 'express';
import { chatWithAiAssistant, getRecommendations, getKnowledgeBase } from '../controllers/aiController.js';
import { optionalAuth, requireAuth } from '../middleware/authMiddleware.js';

const router = express.Router();

router.post('/chat', optionalAuth, chatWithAiAssistant);
router.get('/recommendations', optionalAuth, getRecommendations);
router.get('/knowledge-base', getKnowledgeBase);

export default router;
