import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { 
  Sparkles, 
  Search, 
  MapPin, 
  Filter, 
  Flame, 
  Compass, 
  Film, 
  Music, 
  Trophy, 
  Mic, 
  ChevronRight,
  TrendingUp,
  RefreshCw
} from 'lucide-react';
import { eventAPI, aiAPI } from '../services/api';
import { EventCard } from '../components/EventCard';
import { useAuth } from '../context/AuthContext';

export const HomePage = ({ onOpenAiChat }) => {
  const [searchParams, setSearchParams] = useSearchParams();
  const { user } = useAuth();

  const [events, setEvents] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCity, setSelectedCity] = useState('all');

  const currentCategory = searchParams.get('category') || 'all';
  const currentSearch = searchParams.get('search') || '';

  const cities = ['all', 'Mumbai', 'Bengaluru', 'Delhi'];

  const categories = [
    { id: 'all', label: 'All Experiences', icon: Compass },
    { id: 'movies', label: 'Movies & IMAX', icon: Film },
    { id: 'concerts', label: 'Concerts & Stadiums', icon: Music },
    { id: 'sports', label: 'Live Sports', icon: Trophy },
    { id: 'live-shows', label: 'Standup & Shows', icon: Mic },
    { id: 'experiences', label: 'VR & Attractions', icon: Flame },
  ];

  useEffect(() => {
    fetchEvents();
  }, [currentCategory, currentSearch, selectedCity]);

  useEffect(() => {
    fetchRecommendations();
  }, [user]);

  const fetchEvents = async () => {
    setLoading(true);
    try {
      const params = {};
      if (currentCategory !== 'all') params.category = currentCategory;
      if (selectedCity !== 'all') params.city = selectedCity;
      if (currentSearch) params.search = currentSearch;

      const res = await eventAPI.getAll(params);
      if (res.success) {
        setEvents(res.events || []);
      }
    } catch (err) {
      console.error('Failed to load events:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchRecommendations = async () => {
    try {
      const res = await aiAPI.getRecommendations();
      if (res.success && res.recommendations) {
        setRecommendations(res.recommendations);
      }
    } catch (e) {
      // ignore
    }
  };

  const handleCategoryClick = (catId) => {
    const newParams = new URLSearchParams(searchParams);
    if (catId === 'all') {
      newParams.delete('category');
    } else {
      newParams.set('category', catId);
    }
    setSearchParams(newParams);
  };

  const featuredEvent = events.length > 0 ? events[0] : null;

  return (
    <div className="space-y-12 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-8 pb-12 sm:pt-12 sm:pb-16 px-4">
        {/* Background glow effects */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-fuchsia-600/20 via-purple-600/20 to-indigo-600/10 blur-[120px] rounded-full pointer-events-none" />

        <div className="max-w-7xl mx-auto text-center relative z-10 space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-panel border border-fuchsia-500/30 text-xs font-semibold text-fuchsia-300 shadow-lg shadow-fuchsia-950/40">
            <Sparkles className="w-3.5 h-3.5 text-yellow-300 animate-pulse" />
            <span>AI-Driven Discovery & Real-Time Seat Locking</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-black text-white tracking-tight font-['Space_Grotesk'] max-w-4xl mx-auto leading-tight">
            Discover What Moves You. <br />
            <span className="bg-gradient-to-r from-fuchsia-400 via-purple-400 to-indigo-400 bg-clip-text text-transparent">
              Book Tickets in Seconds.
            </span>
          </h1>

          <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Experience blockbuster IMAX movies, stadium concerts, cricket tournaments, and immersive VR with atomic Redis seat locks and digital cryptographic QR tickets.
          </p>

          {/* Quick AI Search Prompt Bar */}
          <div className="max-w-2xl mx-auto pt-2">
            <div 
              onClick={onOpenAiChat}
              className="glass-dropdown p-2 rounded-2xl border border-fuchsia-500/40 shadow-2xl flex items-center justify-between gap-3 cursor-pointer hover:border-fuchsia-400 transition-all group"
            >
              <div className="flex items-center gap-3 pl-3 text-slate-400 text-xs sm:text-sm">
                <Sparkles className="w-4 h-4 text-fuchsia-400 group-hover:scale-110 transition-transform" />
                <span className="text-slate-300 font-medium">Try asking: "Coldplay concerts in Mumbai" or "Find comedy shows"</span>
              </div>
              <button
                type="button"
                className="px-4 py-2 rounded-xl text-xs font-bold bg-fuchsia-600 text-white shadow-md shadow-fuchsia-600/30 group-hover:bg-fuchsia-500 transition-all flex items-center gap-1 shrink-0"
              >
                <span>Ask AI</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Banner (If available) */}
      {featuredEvent && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative rounded-3xl overflow-hidden glass-panel border border-slate-700/80 shadow-2xl group">
            <div className="absolute inset-0 z-0">
              <img
                src={featuredEvent.bannerUrl}
                alt={featuredEvent.title}
                className="w-full h-full object-cover opacity-35 group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/80 to-transparent" />
            </div>

            <div className="relative z-10 p-6 sm:p-10 max-w-2xl space-y-4">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-fuchsia-600 text-white">
                  Trending Event
                </span>
                <span className="text-xs font-semibold text-fuchsia-300">
                  {featuredEvent.city} • {featuredEvent.venueName}
                </span>
              </div>

              <h2 className="text-2xl sm:text-4xl font-extrabold text-white font-['Space_Grotesk'] leading-tight">
                {featuredEvent.title}
              </h2>

              <p className="text-xs sm:text-sm text-slate-300 line-clamp-3 leading-relaxed">
                {featuredEvent.description}
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-3">
                <Link
                  to={`/event/${featuredEvent._id}`}
                  className="px-6 py-3 rounded-xl text-xs sm:text-sm font-bold bg-gradient-to-r from-fuchsia-600 to-indigo-600 text-white shadow-xl shadow-fuchsia-600/30 hover:scale-105 transition-all flex items-center gap-2"
                >
                  <span>Book Experience</span>
                  <ChevronRight className="w-4 h-4" />
                </Link>
                <span className="text-xs text-slate-400">
                  ⭐ {featuredEvent.rating} / 5.0 ({featuredEvent.totalReviews} verified reviews)
                </span>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Main Catalog & Filter Bar */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {/* Controls Toolbar */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          {/* Category Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 w-full sm:w-auto scrollbar-none">
            {categories.map((cat) => {
              const Icon = cat.icon;
              const isSelected = currentCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => handleCategoryClick(cat.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                    isSelected
                      ? 'bg-fuchsia-600 text-white shadow-lg shadow-fuchsia-600/30'
                      : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>

          {/* City Filter Dropdown */}
          <div className="flex items-center gap-2 text-xs self-end sm:self-auto">
            <MapPin className="w-4 h-4 text-fuchsia-400" />
            <span className="text-slate-400">City:</span>
            <select
              value={selectedCity}
              onChange={(e) => setSelectedCity(e.target.value)}
              className="bg-slate-900 text-slate-200 px-3 py-1.5 rounded-xl border border-slate-700 text-xs font-semibold focus:outline-none focus:border-fuchsia-500"
            >
              {cities.map((c) => (
                <option key={c} value={c}>
                  {c === 'all' ? 'All Cities' : c}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Event Cards Grid */}
        {loading ? (
          <div className="py-20 flex flex-col items-center justify-center text-slate-400 space-y-3">
            <RefreshCw className="w-8 h-8 text-fuchsia-400 animate-spin" />
            <p className="text-sm font-semibold">Discovering live entertainment experiences...</p>
          </div>
        ) : events.length === 0 ? (
          <div className="py-16 text-center glass-panel rounded-3xl p-8 max-w-lg mx-auto space-y-3">
            <Compass className="w-12 h-12 text-slate-500 mx-auto" />
            <h3 className="font-bold text-white text-base">No experiences found</h3>
            <p className="text-xs text-slate-400">
              Try adjusting your category or city filters, or ask the AI Assistant to discover alternatives.
            </p>
            <button
              onClick={() => {
                setSearchParams({});
                setSelectedCity('all');
              }}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-800 text-slate-200 hover:bg-slate-700"
            >
              Clear Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {events.map((evt) => (
              <EventCard key={evt._id} event={evt} />
            ))}
          </div>
        )}
      </section>

      {/* AI Tailored Recommendations Section */}
      {recommendations.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
          <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-fuchsia-950/40 via-purple-950/20 to-slate-900/40 border border-fuchsia-500/20 space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-fuchsia-600/30 border border-fuchsia-500/40">
                  <Sparkles className="w-5 h-5 text-yellow-300" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-lg font-['Space_Grotesk']">
                    Personalized AI Recommendations
                  </h3>
                  <p className="text-xs text-slate-400">
                    Curated based on your interests and past bookings via vector embeddings
                  </p>
                </div>
              </div>
              <button
                onClick={onOpenAiChat}
                className="hidden sm:inline-flex items-center gap-1 text-xs font-bold text-fuchsia-400 hover:text-fuchsia-300"
              >
                <span>Customize in AI Chat</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {recommendations.slice(0, 3).map((evt) => (
                <Link
                  key={evt._id}
                  to={`/event/${evt._id}`}
                  className="flex items-center gap-3 p-3 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-fuchsia-500/50 hover:bg-slate-800/80 transition-all group"
                >
                  <img
                    src={evt.bannerUrl || evt.posterUrl}
                    alt={evt.title}
                    className="w-16 h-16 rounded-xl object-cover bg-slate-800 shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] font-bold uppercase text-fuchsia-400 block">{evt.category}</span>
                    <h4 className="font-bold text-xs text-white truncate group-hover:text-fuchsia-300 transition-colors">
                      {evt.title}
                    </h4>
                    <p className="text-[10px] text-slate-400 truncate mt-0.5">{evt.city} • {evt.venueName}</p>
                    <span className="text-[10px] text-yellow-400 font-bold mt-1 block">⭐ {evt.rating}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
