/**
 * Redis Client & Resilient In-Memory Fallback Adapter
 * Supports standard Redis operations (get, set with NX/EX options, del, keys, ttl, expire)
 * Ensures high performance and local standalone development without requiring external Redis service.
 */

class InMemoryRedisStore {
  constructor() {
    this.store = new Map();
    this.ttls = new Map();
    console.log('⚡ [Redis] Initialized High-Performance In-Memory Redis Engine');
  }

  async get(key) {
    if (!this._checkKey(key)) return null;
    const val = this.store.get(key);
    return typeof val === 'object' ? JSON.stringify(val) : String(val);
  }

  async set(key, value, ...options) {
    // Check for 'NX' (Set only if not exists)
    let nx = false;
    let exSeconds = null;

    for (let i = 0; i < options.length; i++) {
      const opt = String(options[i]).toUpperCase();
      if (opt === 'NX') {
        nx = true;
      } else if (opt === 'EX' && options[i + 1]) {
        exSeconds = parseInt(options[i + 1], 10);
        i++;
      }
    }

    if (nx && this._checkKey(key)) {
      return null; // Key already exists, NX failed
    }

    this.store.set(key, value);

    if (exSeconds && exSeconds > 0) {
      this._setExpiry(key, exSeconds * 1000);
    } else {
      this._clearExpiry(key);
    }

    return 'OK';
  }

  async del(key) {
    this._clearExpiry(key);
    const existed = this.store.delete(key);
    return existed ? 1 : 0;
  }

  async exists(key) {
    return this._checkKey(key) ? 1 : 0;
  }

  async ttl(key) {
    if (!this._checkKey(key)) return -2;
    const expiry = this.ttls.get(key);
    if (!expiry) return -1; // No TTL
    const remaining = Math.ceil((expiry.expiresAt - Date.now()) / 1000);
    return remaining > 0 ? remaining : -2;
  }

  async keys(pattern) {
    const matched = [];
    const regexStr = pattern.replace(/\*/g, '.*');
    const regex = new RegExp(`^${regexStr}$`);

    for (const key of this.store.keys()) {
      if (this._checkKey(key) && regex.test(key)) {
        matched.push(key);
      }
    }
    return matched;
  }

  async flushall() {
    this.store.clear();
    for (const timer of this.ttls.values()) {
      clearTimeout(timer.timeoutId);
    }
    this.ttls.clear();
    return 'OK';
  }

  _checkKey(key) {
    const item = this.ttls.get(key);
    if (item && item.expiresAt <= Date.now()) {
      this.del(key);
      return false;
    }
    return this.store.has(key);
  }

  _setExpiry(key, ms) {
    this._clearExpiry(key);
    const timeoutId = setTimeout(() => {
      this.del(key);
    }, ms);
    this.ttls.set(key, {
      expiresAt: Date.now() + ms,
      timeoutId
    });
  }

  _clearExpiry(key) {
    if (this.ttls.has(key)) {
      clearTimeout(this.ttls.get(key).timeoutId);
      this.ttls.delete(key);
    }
  }
}

// Export singleton instance
export const redisClient = new InMemoryRedisStore();
