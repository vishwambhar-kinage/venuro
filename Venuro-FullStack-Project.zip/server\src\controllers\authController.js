import bcrypt from 'bcryptjs';
import { dataStore } from '../models/dataStore.js';
import { generateToken } from '../middleware/authMiddleware.js';

export const register = async (req, res) => {
  try {
    const { name, email, password, role, preferences } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ success: false, message: 'Please provide name, email, and password.' });
    }

    const existingUser = dataStore.findUserByEmail(email);
    if (existingUser) {
      return res.status(400).json({ success: false, message: 'An account with this email already exists.' });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const newUser = dataStore.createUser({
      name,
      email,
      password: hashedPassword,
      role: role && ['user', 'coordinator', 'admin'].includes(role) ? role : 'user',
      preferences: preferences || ['Concerts', 'Movies']
    });

    const token = generateToken(newUser);

    res.status(201).json({
      success: true,
      message: 'Account created successfully!',
      token,
      user: {
        id: newUser._id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        avatar: newUser.avatar,
        walletBalance: newUser.walletBalance,
        preferences: newUser.preferences
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Please provide email and password.' });
    }

    const user = dataStore.findUserByEmail(email);
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid credentials. User not found.' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid credentials. Password incorrect.' });
    }

    const token = generateToken(user);

    res.json({
      success: true,
      message: 'Logged in successfully!',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        avatar: user.avatar,
        walletBalance: user.walletBalance,
        preferences: user.preferences
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

export const demoLogin = async (req, res) => {
  try {
    const { role = 'user' } = req.body;
    let targetEmail = 'user@venuro.com';

    if (role === 'coordinator') targetEmail = 'coordinator@venuro.com';
    if (role === 'admin') targetEmail = 'admin@venuro.com';

    const user = dataStore.findUserByEmail(targetEmail);
    if (!user) {
      return res.status(404).json({ success: false, message: `Demo account for role '${role}' not found.` });
    }

    const token = generateToken(user);

    res.json({
      success: true,
      message: `Switched to Demo ${role.toUpperCase()} Account!`,
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        avatar: user.avatar,
        walletBalance: user.walletBalance,
        preferences: user.preferences
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

export const getMe = async (req, res) => {
  res.json({
    success: true,
    user: {
      id: req.user._id,
      name: req.user.name,
      email: req.user.email,
      role: req.user.role,
      avatar: req.user.avatar,
      walletBalance: req.user.walletBalance,
      preferences: req.user.preferences
    }
  });
};

export const updateProfile = async (req, res) => {
  try {
    const { name, preferences } = req.body;
    const user = dataStore.findUserById(req.user._id);

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    if (name) user.name = name;
    if (preferences) user.preferences = preferences;

    res.json({
      success: true,
      message: 'Profile updated successfully',
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        avatar: user.avatar,
        walletBalance: user.walletBalance,
        preferences: user.preferences
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
