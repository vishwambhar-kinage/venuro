import bcrypt from 'bcryptjs';
import { dataStore } from '../models/dataStore.js';
import { QRService } from '../services/qrService.js';

export const seedInitialData = async () => {
  console.log('🌱 [Seed] Populating initial entertainment catalog & demo accounts...');

  // Reset store
  dataStore.users = [];
  dataStore.events = [];
  dataStore.shows = [];
  dataStore.bookings = [];
  dataStore.reviews = [];

  const defaultPassword = await bcrypt.hash('password123', 10);

  // 1. Create Demo Users
  const user = dataStore.createUser({
    _id: 'usr_normal_1',
    name: 'Aarav Sharma',
    email: 'user@venuro.com',
    password: defaultPassword,
    role: 'user',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
    walletBalance: 2500,
    preferences: ['Concerts', 'Movies', 'Sports']
  });

  const coordinator = dataStore.createUser({
    _id: 'usr_coord_1',
    name: 'Priya Mehta (Event Coordinator)',
    email: 'coordinator@venuro.com',
    password: defaultPassword,
    role: 'coordinator',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
    walletBalance: 5000,
    preferences: ['Live Shows', 'Concerts']
  });

  const admin = dataStore.createUser({
    _id: 'usr_admin_1',
    name: 'Vikramaditya Roy (Platform Admin)',
    email: 'admin@venuro.com',
    password: defaultPassword,
    role: 'admin',
    avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150',
    walletBalance: 10000,
    preferences: ['All']
  });

  // 2. Create Events across Categories
  const events = [
    {
      _id: 'evt_dune2',
      title: 'Dune: Part Two (IMAX 3D Laser)',
      category: 'movies',
      description: 'Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family. Facing a choice between the love of his life and the fate of the universe.',
      bannerUrl: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1200',
      posterUrl: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=600',
      city: 'Mumbai',
      venueName: 'PVR INOX IMAX Laser, Palladium Lower Parel',
      address: 'High Street Phoenix, Senapati Bapat Marg, Lower Parel, Mumbai',
      duration: '2h 46m',
      language: 'English (Atmos 7.1)',
      genre: ['Sci-Fi', 'Adventure', 'Action'],
      ageLimit: '13+',
      cast: ['Timothée Chalamet', 'Zendaya', 'Rebecca Ferguson', 'Austin Butler'],
      rating: 4.9,
      totalReviews: 342,
      status: 'active',
      coordinatorId: coordinator._id
    },
    {
      _id: 'evt_coldplay',
      title: 'Coldplay: Music of the Spheres World Tour',
      category: 'concerts',
      description: 'Experience the magic of Coldplay live in India! Spectacular stadium visuals, kinetic dance floors, sustainable pyrotechnics, and greatest hits from Yellow to Fix You.',
      bannerUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=1200',
      posterUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600',
      city: 'Mumbai',
      venueName: 'DY Patil Stadium, Navi Mumbai',
      address: 'Sector 7, Nerul, Navi Mumbai, Maharashtra 400706',
      duration: '3h 15m',
      language: 'English',
      genre: ['Pop', 'Rock', 'Live Stadium Tour'],
      ageLimit: 'All Ages',
      cast: ['Chris Martin', 'Jonny Buckland', 'Guy Berryman', 'Will Champion'],
      rating: 5.0,
      totalReviews: 890,
      status: 'active',
      coordinatorId: coordinator._id
    },
    {
      _id: 'evt_diljit',
      title: 'Diljit Dosanjh: Dil-Luminati India Tour',
      category: 'concerts',
      description: 'The biggest Punjabi music phenomenon of the decade. High-octane bhangra, iconic chartbusters like Lover, Born to Shine, and G.O.A.T in a massive stadium setup.',
      bannerUrl: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=1200',
      posterUrl: 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=600',
      city: 'Bengaluru',
      venueName: 'NICE Grounds, Tumkur Road',
      address: 'Bengaluru International Exhibition Centre, Bangalore, Karnataka',
      duration: '3h 00m',
      language: 'Punjabi / Hindi',
      genre: ['Punjabi Pop', 'Hip-Hop', 'Folk Fusion'],
      ageLimit: '6+',
      cast: ['Diljit Dosanjh', 'Live Band & Dancers'],
      rating: 4.9,
      totalReviews: 612,
      status: 'active',
      coordinatorId: coordinator._id
    },
    {
      _id: 'evt_ipl2026',
      title: 'IPL 2026: Mumbai Indians vs Chennai Super Kings (El Clásico)',
      category: 'sports',
      description: 'The greatest rivalry in T20 cricket history. Watch 5-time champions battle under the roaring lights of Wankhede Stadium with deafening crowd energy.',
      bannerUrl: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=1200',
      posterUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600',
      city: 'Mumbai',
      venueName: 'Wankhede Stadium, Churchgate',
      address: 'Vinoo Mankad Rd, Churchgate, Mumbai, Maharashtra 400020',
      duration: '4h 00m',
      language: 'Live Commentary in English / Hindi',
      genre: ['Cricket', 'T20', 'Tournament'],
      ageLimit: 'All Ages',
      cast: ['Rohit Sharma', 'Hardik Pandya', 'MS Dhoni', 'Ruturaj Gaikwad'],
      rating: 4.9,
      totalReviews: 1240,
      status: 'active',
      coordinatorId: coordinator._id
    },
    {
      _id: 'evt_zakir',
      title: 'Zakir Khan: Tathastu & Unreleased Special',
      category: 'live-shows',
      description: 'Join the Sakht Launda himself for an evening of heartwarming nostalgia, signature storytelling, and rib-tickling anecdotes about friendship, family, and romance.',
      bannerUrl: 'https://images.unsplash.com/photo-1585699324551-f6c309eedeca?w=1200',
      posterUrl: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=600',
      city: 'Delhi',
      venueName: 'Siri Fort Auditorium, August Kranti Marg',
      address: 'Asian Games Village Complex, Siri Fort, New Delhi 110049',
      duration: '2h 00m',
      language: 'Hindi',
      genre: ['Standup Comedy', 'Storytelling'],
      ageLimit: '16+',
      cast: ['Zakir Khan'],
      rating: 4.8,
      totalReviews: 480,
      status: 'active',
      coordinatorId: coordinator._id
    },
    {
      _id: 'evt_cyberverse',
      title: 'Cyberverse VR: 4D Hyper-Reality Immersion',
      category: 'experiences',
      description: 'Step into a breathtaking cyberpunk metropolis with full-body haptic feedback suits, scent simulation, wind effects, and free-roam optical tracking headsets.',
      bannerUrl: 'https://images.unsplash.com/photo-1592478411213-6153e4ebc07d?w=1200',
      posterUrl: 'https://images.unsplash.com/photo-1593508512255-86ab42a8e620?w=600',
      city: 'Bengaluru',
      venueName: 'Venuro Experience Arena, Indiranagar',
      address: '100 Feet Road, HAL 2nd Stage, Indiranagar, Bengaluru 560038',
      duration: '1h 15m',
      language: 'Interactive Multilingual',
      genre: ['Virtual Reality', 'Gaming', 'Immersive Tech'],
      ageLimit: '10+',
      cast: ['Haptic Pod Squad'],
      rating: 4.9,
      totalReviews: 215,
      status: 'active',
      coordinatorId: coordinator._id
    }
  ];

  events.forEach(evt => dataStore.createEvent(evt));

  // 3. Create Shows for each Event
  const today = new Date().toISOString().split('T')[0];
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
  const dayAfter = new Date(Date.now() + 172800000).toISOString().split('T')[0];

  const shows = [
    {
      _id: 'shw_dune2_1',
      eventId: 'evt_dune2',
      screenName: 'IMAX Laser Audi 1 (Dolby Atmos)',
      date: today,
      startTime: '16:00',
      endTime: '18:46'
    },
    {
      _id: 'shw_dune2_2',
      eventId: 'evt_dune2',
      screenName: 'IMAX Laser Audi 1 (Dolby Atmos)',
      date: today,
      startTime: '19:45',
      endTime: '22:30'
    },
    {
      _id: 'shw_dune2_3',
      eventId: 'evt_dune2',
      screenName: 'IMAX Laser Audi 1 (Dolby Atmos)',
      date: tomorrow,
      startTime: '20:15',
      endTime: '23:00'
    },
    {
      _id: 'shw_coldplay_1',
      eventId: 'evt_coldplay',
      screenName: 'Main Stadium Arena & VIP Lounge',
      date: tomorrow,
      startTime: '18:00',
      endTime: '21:15'
    },
    {
      _id: 'shw_coldplay_2',
      eventId: 'evt_coldplay',
      screenName: 'Main Stadium Arena & VIP Lounge',
      date: dayAfter,
      startTime: '18:00',
      endTime: '21:15'
    },
    {
      _id: 'shw_diljit_1',
      eventId: 'evt_diljit',
      screenName: 'Grand Outdoor Stage',
      date: tomorrow,
      startTime: '19:00',
      endTime: '22:00'
    },
    {
      _id: 'shw_ipl_1',
      eventId: 'evt_ipl2026',
      screenName: 'Pavilion Stand & Corporate Box',
      date: today,
      startTime: '19:30',
      endTime: '23:30'
    },
    {
      _id: 'shw_zakir_1',
      eventId: 'evt_zakir',
      screenName: 'Main Auditorium',
      date: today,
      startTime: '20:00',
      endTime: '22:00'
    },
    {
      _id: 'shw_vr_1',
      eventId: 'evt_cyberverse',
      screenName: 'Haptic Pod 01 & Arena Grid',
      date: today,
      startTime: '17:30',
      endTime: '18:45'
    }
  ];

  shows.forEach(shw => dataStore.createShow(shw));

  // 4. Create an Initial Sample Booking with QR Code for Demo User
  const demoEvent = dataStore.findEventById('evt_dune2');
  const demoShow = dataStore.findShowById('shw_dune2_2');

  const sampleSeats = [
    { id: 'C5', row: 'C', col: 5, tier: 'PREMIUM', price: 900 },
    { id: 'C6', row: 'C', col: 6, tier: 'PREMIUM', price: 900 }
  ];

  const tempBooking = {
    _id: 'bkg_demo_sample_1',
    bookingNumber: 'VNR-89421-2026',
    finalAmount: 1870,
    seats: sampleSeats
  };

  const sampleQrPayload = QRService.createTicketPayload(tempBooking, demoEvent, demoShow);
  const sampleQrImage = await QRService.generateQRCodeDataUrl(sampleQrPayload);

  dataStore.createBooking({
    _id: tempBooking._id,
    bookingNumber: tempBooking.bookingNumber,
    userId: user._id,
    eventId: demoEvent._id,
    showId: demoShow._id,
    seats: sampleSeats,
    totalAmount: 1800,
    discountAmount: 0,
    convenienceFee: 70,
    finalAmount: 1870,
    paymentDetails: {
      paymentId: 'TXN_SAMPLE_DUNE_99',
      method: 'UPI',
      status: 'SUCCESS',
      timestamp: new Date().toISOString()
    },
    qrCodeData: sampleQrPayload,
    qrCodeImage: sampleQrImage
  });

  // 5. Seed Initial Reviews
  dataStore.createReview({
    userId: user._id,
    userName: 'Aarav Sharma',
    userAvatar: user.avatar,
    eventId: 'evt_dune2',
    rating: 5,
    comment: 'Mind-blowing visuals and Hans Zimmer sound score in IMAX! The seat locking made booking seamless without glitches.'
  });

  dataStore.createReview({
    userId: coordinator._id,
    userName: 'Priya Mehta',
    userAvatar: coordinator.avatar,
    eventId: 'evt_coldplay',
    rating: 5,
    comment: 'The greatest stadium atmosphere ever. The QR code scanner at the gate verified tickets instantly.'
  });

  console.log(`✅ [Seed] Success! Seeded ${dataStore.users.length} Users, ${dataStore.events.length} Events, ${dataStore.shows.length} Shows, ${dataStore.bookings.length} Bookings.`);
};
