import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { 
  Ticket, 
  Sparkles, 
  Search, 
  User as UserIcon, 
  LogOut, 
  Shield, 
  Calendar, 
  CreditCard, 
  Menu, 
  X,
  Compass,
  Film,
  Music,
  Trophy,
  Mic,
  Flame,
  ChevronDown
} from 'lucide-react';

export const Navbar = ({ onOpenAiChat }) => {
  const { user, isAuthenticated, logout, demoLogin, isCoordinator, isAdmin } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  const location = useLocation();

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery('');
    }
  };

  const handleDemoSwitch = async (role) => {
    try {
      await demoLogin(role);
      setUserDropdownOpen(false);
      if (role === 'admin') navigate('/admin');
      else if (role === 'coordinator') navigate('/coordinator');
      else navigate('/user-dashboard');
    } catch (err) {
      console.error(err);
    }
  };

  const navLinks = [
    { name: 'All Events', path: '/', icon: Compass },
    { name: 'Movies', path: '/?category=movies', icon: Film },
    { name: 'Concerts', path: '/?category=concerts', icon: Music },
    { name: 'Sports', path: '/?category=sports', icon: Trophy },
    { name: 'Live Shows', path: '/?category=live-shows', icon: Mic },
    { name: 'Experiences', path: '/?category=experiences', icon: Flame },
  ];

  return (
    <header className="sticky top-0 z-40 w-full glass-panel border-b border-slate-800/80 backdrop-blur-md">
      {/* Top Demo Account Bar */}
      <div className="bg-gradient-to-r from-fuchsia-950/60 via-purple-950/60 to-slate-950/80 border-b border-fuchsia-500/20 px-4 py-1.5 text-xs text-slate-300">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
            <span className="font-medium text-slate-200">Interactive Demo Mode:</span>
            <span className="text-slate-400 hidden sm:inline">Switch instant roles with 1-click &rarr;</span>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => handleDemoSwitch('user')}
              className={`px-2.5 py-0.5 rounded-full text-xs font-semibold transition-all ${
                user?.role === 'user' 
                  ? 'bg-fuchsia-600 text-white shadow-sm' 
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
              }`}
            >
              👤 Guest User
            </button>
            <button
              onClick={() => handleDemoSwitch('coordinator')}
              className={`px-2.5 py-0.5 rounded-full text-xs font-semibold transition-all ${
                user?.role === 'coordinator' 
                  ? 'bg-amber-600 text-white shadow-sm' 
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
              }`}
            >
              🎪 Event Coordinator
            </button>
            <button
              onClick={() => handleDemoSwitch('admin')}
              className={`px-2.5 py-0.5 rounded-full text-xs font-semibold transition-all ${
                user?.role === 'admin' 
                  ? 'bg-purple-600 text-white shadow-sm' 
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
              }`}
            >
              🛡️ Admin
            </button>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-fuchsia-600 to-indigo-600 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform duration-200">
              <Ticket className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-xl font-black tracking-tight text-white flex items-center gap-1 font-['Space_Grotesk']">
                VENURO
                <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 bg-fuchsia-500/20 text-fuchsia-400 rounded-md border border-fuchsia-500/30">
                  AI
                </span>
              </span>
            </div>
          </Link>

          {/* Search Bar */}
          <form onSubmit={handleSearchSubmit} className="hidden md:flex flex-1 max-w-md relative">
            <input
              type="text"
              placeholder="Search movies, concerts, artists, venues..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900/90 text-sm text-slate-200 pl-10 pr-4 py-2 rounded-xl border border-slate-700/60 focus:outline-none focus:border-fuchsia-500 focus:ring-1 focus:ring-fuchsia-500 transition-all placeholder:text-slate-500"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          </form>

          {/* Right Action Icons & AI Button */}
          <div className="flex items-center gap-3">
            {/* AI Assistant Button */}
            <button
              onClick={onOpenAiChat}
              className="relative flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-semibold bg-gradient-to-r from-fuchsia-600/90 via-purple-600/90 to-indigo-600/90 text-white shadow-lg shadow-fuchsia-600/20 hover:shadow-fuchsia-600/40 hover:scale-[1.02] active:scale-[0.98] transition-all"
            >
              <Sparkles className="w-4 h-4 text-yellow-300 animate-pulse" />
              <span>Ask AI Assistant</span>
              <span className="absolute -top-1.5 -right-1.5 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-fuchsia-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-fuchsia-500"></span>
              </span>
            </button>

            {/* User Profile / Auth State */}
            {isAuthenticated ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 transition-all"
                >
                  <img
                    src={user?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.name}`}
                    alt={user?.name}
                    className="w-8 h-8 rounded-lg object-cover bg-slate-900"
                  />
                  <div className="hidden lg:block text-left pr-1">
                    <p className="text-xs font-semibold text-slate-200 leading-tight truncate max-w-[100px]">{user?.name}</p>
                    <p className="text-[10px] text-fuchsia-400 uppercase font-bold tracking-wider">{user?.role}</p>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden lg:block" />
                </button>

                {/* Dropdown Menu */}
                {userDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 glass-dropdown rounded-2xl shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95 duration-100">
                    <div className="px-3 py-2 border-b border-slate-800 mb-1">
                      <p className="text-xs font-semibold text-white truncate">{user?.name}</p>
                      <p className="text-[11px] text-slate-400 truncate">{user?.email}</p>
                      <div className="mt-2 flex items-center justify-between text-xs bg-slate-900/90 px-2 py-1 rounded-lg border border-slate-800">
                        <span className="text-slate-400">Wallet Balance:</span>
                        <span className="font-bold text-emerald-400">₹{user?.walletBalance || 0}</span>
                      </div>
                    </div>

                    <Link
                      to="/user-dashboard"
                      onClick={() => setUserDropdownOpen(false)}
                      className="flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-xl transition-all"
                    >
                      <Ticket className="w-4 h-4 text-fuchsia-400" />
                      My Bookings & QR Passes
                    </Link>

                    {isCoordinator && (
                      <Link
                        to="/coordinator"
                        onClick={() => setUserDropdownOpen(false)}
                        className="flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-amber-300 hover:text-amber-200 hover:bg-amber-500/10 rounded-xl transition-all"
                      >
                        <Calendar className="w-4 h-4 text-amber-400" />
                        Coordinator Dashboard
                      </Link>
                    )}

                    {isAdmin && (
                      <Link
                        to="/admin"
                        onClick={() => setUserDropdownOpen(false)}
                        className="flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-purple-300 hover:text-purple-200 hover:bg-purple-500/10 rounded-xl transition-all"
                      >
                        <Shield className="w-4 h-4 text-purple-400" />
                        Admin Control Center
                      </Link>
                    )}

                    <div className="border-t border-slate-800 my-1"></div>

                    <button
                      onClick={() => {
                        logout();
                        setUserDropdownOpen(false);
                        navigate('/');
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 rounded-xl transition-all text-left"
                    >
                      <LogOut className="w-4 h-4" />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Link
                to="/auth"
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 transition-all"
              >
                <UserIcon className="w-4 h-4 text-slate-300" />
                <span>Sign In</span>
              </Link>
            )}

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-xl bg-slate-800/80 text-slate-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Category Navigation Ribbon */}
        <nav className="hidden md:flex items-center space-x-1 py-2 border-t border-slate-800/60 overflow-x-auto text-xs font-semibold scrollbar-none">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive = location.pathname + location.search === link.path;
            return (
              <Link
                key={link.name}
                to={link.path}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-fuchsia-500/20 text-fuchsia-300 border border-fuchsia-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {link.name}
              </Link>
            );
          })}
        </nav>
      </div>

      {/* Mobile Navigation Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden glass-dropdown border-b border-slate-800 px-4 pt-2 pb-4 space-y-2">
          <form onSubmit={handleSearchSubmit} className="relative mb-3">
            <input
              type="text"
              placeholder="Search entertainment..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 text-sm text-slate-200 pl-9 pr-4 py-2 rounded-xl border border-slate-700"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          </form>

          <div className="grid grid-cols-2 gap-2">
            {navLinks.map((link) => {
              const Icon = link.icon;
              return (
                <Link
                  key={link.name}
                  to={link.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-900/60 text-xs font-medium text-slate-300 hover:bg-slate-800"
                >
                  <Icon className="w-4 h-4 text-fuchsia-400" />
                  {link.name}
                </Link>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
};
