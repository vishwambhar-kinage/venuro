import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  TrendingUp, 
  Users, 
  Ticket, 
  DollarSign, 
  Activity, 
  Cpu, 
  Database, 
  Lock, 
  CheckCircle2, 
  XCircle, 
  RefreshCw,
  Eye,
  Settings
} from 'lucide-react';
import { adminAPI } from '../services/api';

export const AdminDashboardPage = () => {
  const [analytics, setAnalytics] = useState(null);
  const [usersList, setUsersList] = useState([]);
  const [systemHealth, setSystemHealth] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview'); // 'overview' | 'users' | 'system'
  const [roleUpdateMsg, setRoleUpdateMsg] = useState('');

  useEffect(() => {
    fetchAdminData();
  }, []);

  const fetchAdminData = async () => {
    setLoading(true);
    try {
      const [analyticsRes, usersRes, healthRes] = await Promise.all([
        adminAPI.getAnalytics(),
        adminAPI.getUsers(),
        adminAPI.getHealth()
      ]);

      if (analyticsRes.success) setAnalytics(analyticsRes);
      if (usersRes.success) setUsersList(usersRes.users || []);
      if (healthRes.success) setSystemHealth(healthRes.system);
    } catch (err) {
      console.error('Failed to load admin telemetry:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRoleChange = async (userId, newRole) => {
    try {
      const res = await adminAPI.updateUserRole(userId, newRole);
      if (res.success) {
        setRoleUpdateMsg(res.message);
        setUsersList((prev) =>
          prev.map((u) => (u.id === userId ? { ...u, role: newRole } : u))
        );
        setTimeout(() => setRoleUpdateMsg(''), 2500);
      }
    } catch (err) {
      setRoleUpdateMsg(`Error: ${err.message}`);
    }
  };

  if (loading) {
    return (
      <div className="py-32 flex flex-col items-center justify-center text-slate-400 space-y-3">
        <RefreshCw className="w-8 h-8 text-purple-400 animate-spin" />
        <p className="text-xs font-semibold">Loading platform analytics & telemetry...</p>
      </div>
    );
  }

  const metrics = analytics?.metrics || {};
  const categoryRev = analytics?.categoryRevenue || {};

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 pb-20">
      {/* Header Bar */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-purple-500/30 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center gap-1">
              <Shield className="w-3.5 h-3.5" />
              Platform Command Center
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-['Space_Grotesk']">
            Platform Analytics & Governance
          </h1>
          <p className="text-xs text-slate-400">
            Real-time Gross Merchandise Value (GMV), user access control, Redis lock health, and vector AI diagnostics.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1.5 p-1.5 rounded-2xl bg-slate-900 border border-slate-800 self-start md:self-auto text-xs font-bold">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3.5 py-2 rounded-xl transition-all ${
              activeTab === 'overview'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`px-3.5 py-2 rounded-xl transition-all ${
              activeTab === 'users'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Users ({usersList.length})
          </button>
          <button
            onClick={() => setActiveTab('system')}
            className={`px-3.5 py-2 rounded-xl transition-all ${
              activeTab === 'system'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            System Health
          </button>
        </div>
      </div>

      {roleUpdateMsg && (
        <div className="p-3.5 rounded-2xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-200 text-xs font-semibold animate-in fade-in">
          {roleUpdateMsg}
        </div>
      )}

      {/* Tab 1: Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* Top KPI Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="glass-panel p-5 rounded-2xl border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-slate-400 flex items-center justify-between">
                <span>Total GMV (Revenue)</span>
                <DollarSign className="w-4 h-4 text-amber-400" />
              </span>
              <p className="text-2xl sm:text-3xl font-black text-white font-mono">₹{metrics.totalGMV || 0}</p>
              <span className="text-[10px] text-emerald-400 font-semibold block">
                Net: ₹{metrics.netRevenue || 0} (₹{metrics.totalRefunds || 0} refunded)
              </span>
            </div>

            <div className="glass-panel p-5 rounded-2xl border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-slate-400 flex items-center justify-between">
                <span>Total Bookings</span>
                <Ticket className="w-4 h-4 text-fuchsia-400" />
              </span>
              <p className="text-2xl sm:text-3xl font-black text-white font-mono">{metrics.totalBookings || 0}</p>
              <span className="text-[10px] text-slate-400 font-semibold block">
                {metrics.totalTicketsSold || 0} total tickets issued
              </span>
            </div>

            <div className="glass-panel p-5 rounded-2xl border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-slate-400 flex items-center justify-between">
                <span>Registered Users</span>
                <Users className="w-4 h-4 text-blue-400" />
              </span>
              <p className="text-2xl sm:text-3xl font-black text-white font-mono">{metrics.totalUsers || 0}</p>
              <span className="text-[10px] text-blue-400 font-semibold block">
                Roles: Users, Coordinators, Admins
              </span>
            </div>

            <div className="glass-panel p-5 rounded-2xl border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-slate-400 flex items-center justify-between">
                <span>Active Redis Locks</span>
                <Lock className="w-4 h-4 text-emerald-400" />
              </span>
              <p className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono">
                {metrics.activeSeatLocksCount || 0}
              </p>
              <span className="text-[10px] text-slate-400 font-semibold block">
                5-Min concurrency protection
              </span>
            </div>
          </div>

          {/* Revenue by Category Breakdown */}
          <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-slate-800 space-y-5">
            <h2 className="text-base font-bold text-white font-['Space_Grotesk']">
              Revenue Distribution by Entertainment Category
            </h2>

            <div className="space-y-3">
              {[
                { label: 'Movies & IMAX 3D', key: 'movies', color: 'bg-blue-500' },
                { label: 'Concerts & Stadiums', key: 'concerts', color: 'bg-fuchsia-500' },
                { label: 'Live Sports', key: 'sports', color: 'bg-emerald-500' },
                { label: 'Standup & Live Shows', key: 'live-shows', color: 'bg-amber-500' },
                { label: 'VR & Experiences', key: 'experiences', color: 'bg-purple-500' },
              ].map((item) => {
                const amount = categoryRev[item.key] || 0;
                const pct = metrics.totalGMV > 0 ? Math.round((amount / metrics.totalGMV) * 100) : 0;

                return (
                  <div key={item.key} className="space-y-1 text-xs">
                    <div className="flex justify-between font-semibold">
                      <span className="text-slate-300">{item.label}</span>
                      <span className="text-slate-200 font-mono">₹{amount} ({pct}%)</span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-900 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${item.color} transition-all duration-500`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Recent Audit Bookings Table */}
          <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-slate-800 space-y-4">
            <h2 className="text-base font-bold text-white font-['Space_Grotesk']">
              Recent Platform Transactions Audit
            </h2>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-500 uppercase text-[10px] font-bold">
                    <th className="py-2.5">Booking No</th>
                    <th className="py-2.5">Customer</th>
                    <th className="py-2.5">Experience</th>
                    <th className="py-2.5">Seats</th>
                    <th className="py-2.5">Amount</th>
                    <th className="py-2.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {analytics?.recentBookings?.map((b) => (
                    <tr key={b.id} className="hover:bg-slate-900/60 transition-colors">
                      <td className="py-3 font-mono font-bold text-white">{b.bookingNumber}</td>
                      <td className="py-3">
                        <div className="font-semibold text-slate-200">{b.user.name}</div>
                        <div className="text-[10px] text-slate-500">{b.user.email}</div>
                      </td>
                      <td className="py-3 font-medium text-slate-200">{b.eventTitle}</td>
                      <td className="py-3 font-mono text-fuchsia-400 font-bold">{b.seatsCount} Seats</td>
                      <td className="py-3 font-mono font-bold text-white">₹{b.amount}</td>
                      <td className="py-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          b.status === 'CONFIRMED'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        }`}>
                          {b.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Users Management */}
      {activeTab === 'users' && (
        <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-base font-bold text-white font-['Space_Grotesk']">
                User Access & Role Assignment
              </h2>
              <p className="text-xs text-slate-400">Promote or adjust authorization permissions across the system</p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-500 uppercase text-[10px] font-bold">
                  <th className="py-2.5">User</th>
                  <th className="py-2.5">Email</th>
                  <th className="py-2.5">Wallet Balance</th>
                  <th className="py-2.5">Bookings</th>
                  <th className="py-2.5">Current Role</th>
                  <th className="py-2.5">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {usersList.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-900/60 transition-colors">
                    <td className="py-3 flex items-center gap-2.5">
                      <img src={u.avatar} alt={u.name} className="w-7 h-7 rounded-full bg-slate-800" />
                      <span className="font-bold text-white">{u.name}</span>
                    </td>
                    <td className="py-3 text-slate-400 font-mono text-[11px]">{u.email}</td>
                    <td className="py-3 font-mono font-bold text-emerald-400">₹{u.walletBalance || 0}</td>
                    <td className="py-3 font-mono">{u.bookingsCount}</td>
                    <td className="py-3">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        u.role === 'admin'
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                          : u.role === 'coordinator'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-slate-800 text-slate-300'
                      }`}>
                        {u.role}
                      </span>
                    </td>
                    <td className="py-3">
                      <select
                        value={u.role}
                        onChange={(e) => handleRoleChange(u.id, e.target.value)}
                        className="bg-slate-900 text-slate-200 px-2 py-1 rounded-lg border border-slate-700 text-xs font-semibold focus:outline-none focus:border-purple-500"
                      >
                        <option value="user">User</option>
                        <option value="coordinator">Coordinator</option>
                        <option value="admin">Admin</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: System Health */}
      {activeTab === 'system' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-slate-800 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Cpu className="w-5 h-5 text-purple-400" />
              <span>Engine Status & Uptime</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-900 flex justify-between">
                <span className="text-slate-400">System Overall Status</span>
                <span className="font-bold text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> HEALTHY
                </span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-900 flex justify-between">
                <span className="text-slate-400">Memory Usage</span>
                <span className="font-bold text-slate-200 font-mono">{systemHealth?.memoryUsageMB} MB</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-900 flex justify-between">
                <span className="text-slate-400">Process Uptime</span>
                <span className="font-bold text-slate-200 font-mono">{systemHealth?.uptimeSeconds}s</span>
              </div>
            </div>
          </div>

          <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-slate-800 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Database className="w-5 h-5 text-emerald-400" />
              <span>Redis & Vector RAG State</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-900 flex justify-between">
                <span className="text-slate-400">Redis Lock Concurrency</span>
                <span className="font-bold text-emerald-400">ONLINE (Active)</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-900 flex justify-between">
                <span className="text-slate-400">Vector Search Dimensions</span>
                <span className="font-bold text-fuchsia-400 font-mono">256 Sparse/Dense Embeddings</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-900 flex justify-between">
                <span className="text-slate-400">Active Seat Locks in Cache</span>
                <span className="font-bold text-amber-400 font-mono">{systemHealth?.redis?.activeSeatLocks || 0}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
