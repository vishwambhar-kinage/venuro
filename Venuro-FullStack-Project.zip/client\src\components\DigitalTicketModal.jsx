import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  X, 
  Download, 
  Printer, 
  CheckCircle2, 
  Calendar, 
  Clock, 
  MapPin, 
  Ticket, 
  ShieldCheck,
  ChevronRight
} from 'lucide-react';

export const DigitalTicketModal = ({ isOpen, onClose, booking }) => {
  const navigate = useNavigate();

  if (!isOpen || !booking) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md glass-dropdown rounded-3xl border border-fuchsia-500/40 shadow-2xl shadow-fuchsia-950/60 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-fuchsia-900/60 via-purple-900/60 to-slate-900/90 border-b border-fuchsia-500/20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span className="font-bold text-white text-sm">Booking Confirmed!</span>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Pass Card Container (Printable Area) */}
        <div className="p-5 overflow-y-auto space-y-4 printable-ticket">
          <div className="relative rounded-2xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 border border-slate-700/80 p-5 shadow-inner">
            {/* Top Pass Branding */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-fuchsia-600 flex items-center justify-center">
                  <Ticket className="w-4 h-4 text-white" />
                </div>
                <span className="font-black text-white text-sm font-['Space_Grotesk'] tracking-wider">VENURO PASS</span>
              </div>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {booking.bookingStatus || 'CONFIRMED'}
              </span>
            </div>

            {/* Event Info */}
            <div className="space-y-1 mb-4">
              <h3 className="font-extrabold text-base text-white leading-tight">
                {booking.eventTitle || booking.event?.title || 'Live Experience'}
              </h3>
              <p className="text-xs text-slate-400 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-fuchsia-400 shrink-0" />
                <span>{booking.venueName || booking.event?.venueName}</span>
              </p>
            </div>

            {/* Grid details */}
            <div className="grid grid-cols-2 gap-3 py-3 border-y border-dashed border-slate-800 text-xs">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 block">Date</span>
                <span className="font-semibold text-slate-200 flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-fuchsia-400" />
                  {booking.showDate || booking.show?.date}
                </span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 block">Showtime</span>
                <span className="font-semibold text-slate-200 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-fuchsia-400" />
                  {booking.showTime || booking.show?.startTime}
                </span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 block">Screen / Audi</span>
                <span className="font-semibold text-slate-200 truncate block">
                  {booking.screenName || booking.show?.screenName || 'Main Audi'}
                </span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 block">Seats</span>
                <span className="font-bold text-fuchsia-400 font-mono">
                  {booking.seats?.map(s => s.id).join(', ')}
                </span>
              </div>
            </div>

            {/* QR Code Section */}
            <div className="pt-4 flex flex-col items-center justify-center text-center">
              {booking.qrCodeImage ? (
                <div className="p-3 bg-white rounded-2xl shadow-xl border-4 border-slate-800">
                  <img
                    src={booking.qrCodeImage}
                    alt="Entry QR Ticket"
                    className="w-40 h-40 object-contain"
                  />
                </div>
              ) : (
                <div className="w-40 h-40 bg-slate-800 rounded-2xl flex items-center justify-center text-xs text-slate-400">
                  QR Generated
                </div>
              )}

              <p className="text-xs font-mono font-bold text-slate-300 mt-3 tracking-wider">
                {booking.bookingNumber}
              </p>
              <p className="text-[10px] text-slate-500 flex items-center gap-1 mt-0.5">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                <span>Cryptographically Signed Entry Pass</span>
              </p>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-900/90 border-t border-slate-800 flex items-center justify-between gap-2">
          <button
            onClick={handlePrint}
            className="flex-1 px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 border border-slate-700 flex items-center justify-center gap-1.5 transition-all"
          >
            <Printer className="w-4 h-4" />
            <span>Print / Save PDF</span>
          </button>

          <button
            onClick={() => {
              onClose();
              navigate('/user-dashboard');
            }}
            className="flex-1 px-3 py-2.5 rounded-xl bg-fuchsia-600 hover:bg-fuchsia-500 text-xs font-bold text-white shadow-lg shadow-fuchsia-600/20 flex items-center justify-center gap-1.5 transition-all"
          >
            <span>My Bookings</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
