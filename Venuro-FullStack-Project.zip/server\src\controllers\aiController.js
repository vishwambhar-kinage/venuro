import { RAGService } from '../services/ragService.js';
import { dataStore } from '../models/dataStore.js';

export const chatWithAiAssistant = async (req, res) => {
  try {
    const { message, history } = req.body;

    if (!message || !message.trim()) {
      return res.status(400).json({ success: false, message: 'Message is required' });
    }

    const aiResponse = await RAGService.askAiAssistant(message, req.user);

    res.json({
      success: true,
      data: aiResponse
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

export const getRecommendations = async (req, res) => {
  try {
    const userId = req.user ? req.user._id : 'guest';
    const recommendations = RAGService.getPersonalizedRecommendations(userId);

    res.json({
      success: true,
      recommendations
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

export const getKnowledgeBase = async (req, res) => {
  try {
    res.json({
      success: true,
      knowledgeBase: [
        {
          id: 'kb_refund_policy',
          category: 'policies',
          title: 'Cancellation and Refund Policy',
          content: 'Full refunds for cancellations >24 hours prior. 70% refund for 4-24 hours. Under 4 hours non-refundable.'
        },
        {
          id: 'kb_seat_locking',
          category: 'booking_faq',
          title: 'Real-Time Seat Locking Mechanism',
          content: 'Redis-backed locks hold seats exclusively for 5 minutes (300 seconds) with automated expiration.'
        },
        {
          id: 'kb_qr_tickets',
          category: 'booking_faq',
          title: 'Digital QR Tickets and Entry Verification',
          content: 'Cryptographically signed QR codes for instant gate scanner validation.'
        }
      ]
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
