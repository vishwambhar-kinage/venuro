import React from 'react';
import { Ticket, Sparkles, Shield, Cpu, Cloud, Database, Lock, Github } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="mt-20 border-t border-slate-800/80 bg-[#060911] text-slate-400 text-sm">
      {/* Tech Stack Callout Banner */}
      <div className="border-b border-slate-800/60 bg-slate-900/40 py-6 px-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-fuchsia-400" />
            <span className="font-semibold text-slate-300">Enterprise Architecture:</span>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <span className="px-2.5 py-1 rounded-md bg-slate-800 text-slate-300 border border-slate-700 font-mono">React 18 + Vite</span>
            <span className="px-2.5 py-1 rounded-md bg-slate-800 text-slate-300 border border-slate-700 font-mono">Node.js + Express</span>
            <span className="px-2.5 py-1 rounded-md bg-emerald-950/60 text-emerald-300 border border-emerald-800/60 font-mono flex items-center gap-1">
              <Database className="w-3 h-3" /> MongoDB Atlas Vector Search
            </span>
            <span className="px-2.5 py-1 rounded-md bg-red-950/60 text-red-300 border border-red-800/60 font-mono flex items-center gap-1">
              <Lock className="w-3 h-3" /> Redis Seat Locks
            </span>
            <span className="px-2.5 py-1 rounded-md bg-purple-950/60 text-purple-300 border border-purple-800/60 font-mono flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> AI RAG Assistant
            </span>
            <span className="px-2.5 py-1 rounded-md bg-blue-950/60 text-blue-300 border border-blue-800/60 font-mono flex items-center gap-1">
              <Cloud className="w-3 h-3" /> Docker & AWS ECS
            </span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Col 1 */}
          <div className="space-y-4 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-fuchsia-600 to-indigo-600 flex items-center justify-center">
                <Ticket className="w-4 h-4 text-white" />
              </div>
              <span className="text-lg font-black text-white font-['Space_Grotesk']">VENURO</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              AI-Powered entertainment discovery, real-time seat reservation, and cryptographically verified digital ticketing.
            </p>
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>PCI-DSS & HMAC QR Security Compliant</span>
            </div>
          </div>

          {/* Col 2 */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3">Categories</h4>
            <ul className="space-y-2 text-xs">
              <li><a href="/?category=movies" className="hover:text-fuchsia-400 transition-colors">Movies & IMAX 3D</a></li>
              <li><a href="/?category=concerts" className="hover:text-fuchsia-400 transition-colors">Stadium Tours & Concerts</a></li>
              <li><a href="/?category=sports" className="hover:text-fuchsia-400 transition-colors">Cricket & Sports Matches</a></li>
              <li><a href="/?category=live-shows" className="hover:text-fuchsia-400 transition-colors">Standup Comedy & Theater</a></li>
              <li><a href="/?category=experiences" className="hover:text-fuchsia-400 transition-colors">VR & Immersive Experiences</a></li>
            </ul>
          </div>

          {/* Col 3 */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3">Booking Features</h4>
            <ul className="space-y-2 text-xs">
              <li className="flex items-center gap-1.5"><span className="text-fuchsia-400">⚡</span> 5-Min Redis Seat Locking</li>
              <li className="flex items-center gap-1.5"><span className="text-fuchsia-400">🛡️</span> Zero Double-Booking Guarantee</li>
              <li className="flex items-center gap-1.5"><span className="text-fuchsia-400">📱</span> Cryptographic QR Tickets</li>
              <li className="flex items-center gap-1.5"><span className="text-fuchsia-400">💳</span> Instant Wallet Refunds (100% / 70%)</li>
              <li className="flex items-center gap-1.5"><span className="text-fuchsia-400">🤖</span> Natural Language RAG Q&A</li>
            </ul>
          </div>

          {/* Col 4 */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3">Platform Demo Roles</h4>
            <p className="text-xs text-slate-400 mb-3">
              Experience the 3 tailored portals in real time:
            </p>
            <div className="space-y-1.5 text-xs">
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                <span className="font-semibold text-slate-300">User:</span> Browse, lock seats, book & cancel.
              </div>
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                <span className="font-semibold text-slate-300">Coordinator:</span> Create events & scan QR tickets.
              </div>
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                <span className="font-semibold text-slate-300">Admin:</span> GMV metrics, user roles, system health.
              </div>
            </div>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500">
          <p>© 2026 Venuro Entertainment Technologies Inc. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span>Powered by MongoDB Vector Search & Redis Engine</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
