import { dataStore } from '../models/dataStore.js';
import { redisClient } from '../config/redis.js';

export const getPlatformAnalytics = async (req, res) => {
  try {
    const allBookings = dataStore.getAllBookings();
    const confirmedBookings = allBookings.filter(b => b.bookingStatus === 'CONFIRMED');
    const cancelledBookings = allBookings.filter(b => b.bookingStatus === 'CANCELLED');

    const totalGMV = confirmedBookings.reduce((sum, b) => sum + (b.finalAmount || 0), 0);
    const totalRefunds = cancelledBookings.reduce((sum, b) => sum + (b.refundAmount || 0), 0);
    const totalTicketsSold = confirmedBookings.reduce((sum, b) => sum + (b.seats ? b.seats.length : 0), 0);

    // Revenue by Category
    const categoryRevenue = {
      movies: 0,
      concerts: 0,
      sports: 0,
      'live-shows': 0,
      experiences: 0
    };

    confirmedBookings.forEach(b => {
      const evt = dataStore.findEventById(b.eventId);
      if (evt && categoryRevenue[evt.category] !== undefined) {
        categoryRevenue[evt.category] += (b.finalAmount || 0);
      }
    });

    const activeLocksKeys = await redisClient.keys('lock:show:*');

    res.json({
      success: true,
      metrics: {
        totalGMV,
        netRevenue: totalGMV - totalRefunds,
        totalRefunds,
        totalBookings: allBookings.length,
        confirmedBookingsCount: confirmedBookings.length,
        cancelledBookingsCount: cancelledBookings.length,
        totalTicketsSold,
        totalUsers: dataStore.users.length,
        totalEvents: dataStore.events.length,
        activeEvents: dataStore.events.filter(e => e.status === 'active').length,
        activeSeatLocksCount: activeLocksKeys.length
      },
      categoryRevenue,
      recentBookings: allBookings.slice(0, 8).map(b => {
        const evt = dataStore.findEventById(b.eventId);
        const usr = dataStore.findUserById(b.userId);
        return {
          id: b._id,
          bookingNumber: b.bookingNumber,
          user: usr ? { name: usr.name, email: usr.email } : { name: 'Guest', email: 'guest@venuro.com' },
          eventTitle: evt ? evt.title : 'Event',
          category: evt ? evt.category : 'General',
          amount: b.finalAmount,
          seatsCount: b.seats ? b.seats.length : 0,
          status: b.bookingStatus,
          createdAt: b.createdAt
        };
      })
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

export const getAllUsers = async (req, res) => {
  try {
    const sanitizedUsers = dataStore.users.map(u => ({
      id: u._id,
      name: u.name,
      email: u.email,
      role: u.role,
      avatar: u.avatar,
      walletBalance: u.walletBalance,
      createdAt: u.createdAt,
      bookingsCount: dataStore.getBookingsForUser(u._id).length
    }));

    res.json({
      success: true,
      users: sanitizedUsers
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

export const updateUserRole = async (req, res) => {
  try {
    const { userId } = req.params;
    const { role } = req.body;

    if (!role || !['user', 'coordinator', 'admin'].includes(role)) {
      return res.status(400).json({ success: false, message: 'Invalid role specified' });
    }

    const user = dataStore.findUserById(userId);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    user.role = role;

    res.json({
      success: true,
      message: `User ${user.name}'s role updated to ${role.toUpperCase()}`,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

export const moderateEvent = async (req, res) => {
  try {
    const { eventId } = req.params;
    const { status } = req.body; // 'active' | 'suspended'

    const event = dataStore.findEventById(eventId);
    if (!event) {
      return res.status(404).json({ success: false, message: 'Event not found' });
    }

    event.status = status || (event.status === 'active' ? 'suspended' : 'active');

    res.json({
      success: true,
      message: `Event status updated to ${event.status}`,
      event
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

export const getSystemHealth = async (req, res) => {
  try {
    const activeLockKeys = await redisClient.keys('lock:show:*');

    res.json({
      success: true,
      system: {
        status: 'HEALTHY',
        uptimeSeconds: Math.floor(process.uptime()),
        memoryUsageMB: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
        redis: {
          engine: 'Redis In-Memory Engine / Cluster Ready',
          activeSeatLocks: activeLockKeys.length,
          status: 'CONNECTED'
        },
        database: {
          status: 'ONLINE',
          collections: ['users', 'events', 'shows', 'bookings', 'reviews', 'knowledge_base']
        },
        aiRAG: {
          status: 'READY',
          vectorIndexDimensions: 256,
          knowledgeBaseEntries: 5
        }
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
