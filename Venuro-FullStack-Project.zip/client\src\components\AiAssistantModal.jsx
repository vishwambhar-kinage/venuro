import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Sparkles, 
  X, 
  Send, 
  Bot, 
  User, 
  Ticket, 
  HelpCircle, 
  ShieldAlert, 
  Calendar,
  ChevronRight,
  Maximize2,
  Minimize2,
  RefreshCw
} from 'lucide-react';
import { aiAPI } from '../services/api';

export const AiAssistantModal = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState([
    {
      id: 'welcome',
      sender: 'ai',
      text: "👋 Hi! I'm **Venuro AI Assistant**.\n\nI can help you find upcoming concerts, movies, cricket matches, and comedy shows, explain venue rules, check real-time seat locking, and guide you through ticket bookings.\n\nWhat would you like to discover today?",
      suggestedFollowUps: [
        'Concerts in Mumbai',
        'What is your refund policy?',
        'How does 5-minute seat locking work?',
        'Find comedy shows this weekend'
      ]
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [loading, setLoading] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (textToSend) => {
    const query = (textToSend || inputValue).trim();
    if (!query || loading) return;

    const userMessageId = `usr_${Date.now()}`;
    const newMessages = [
      ...messages,
      { id: userMessageId, sender: 'user', text: query }
    ];
    setMessages(newMessages);
    setInputValue('');
    setLoading(true);

    try {
      const res = await aiAPI.chat(query, messages.slice(-4));
      if (res.success && res.data) {
        setMessages((prev) => [
          ...prev,
          {
            id: `ai_${Date.now()}`,
            sender: 'ai',
            text: res.data.answer,
            matchedEvents: res.data.matchedEvents || [],
            suggestedFollowUps: res.data.suggestedFollowUps || []
          }
        ]);
      }
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err_${Date.now()}`,
          sender: 'ai',
          text: `⚠️ Apologies, I encountered an issue retrieving that information: ${err.message}`
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className={`w-full ${isExpanded ? 'sm:max-w-4xl h-[90vh]' : 'sm:max-w-xl h-[85vh] sm:h-[680px]'} flex flex-col rounded-t-3xl sm:rounded-3xl glass-dropdown border border-fuchsia-500/30 shadow-2xl shadow-fuchsia-950/50 overflow-hidden transition-all duration-300`}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-fuchsia-950/80 via-purple-950/80 to-slate-950/90 px-5 py-4 border-b border-fuchsia-500/20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-fuchsia-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-fuchsia-500/20">
              <Sparkles className="w-5 h-5 text-yellow-300 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-white text-base font-['Space_Grotesk']">Venuro RAG Assistant</h3>
                <span className="px-2 py-0.5 text-[10px] font-bold uppercase rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Vector AI
                </span>
              </div>
              <p className="text-xs text-slate-400">Contextual search, venue policies & recommendations</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="hidden sm:inline-flex p-2 text-slate-400 hover:text-white hover:bg-slate-800/80 rounded-xl transition-all"
              title={isExpanded ? 'Collapse' : 'Expand'}
            >
              {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800/80 rounded-xl transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Message Stream */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {messages.map((msg) => {
            const isUser = msg.sender === 'user';
            return (
              <div key={msg.id} className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}>
                {!isUser && (
                  <div className="w-8 h-8 rounded-xl bg-fuchsia-600/30 border border-fuchsia-500/40 flex items-center justify-center shrink-0 mt-0.5">
                    <Bot className="w-4 h-4 text-fuchsia-300" />
                  </div>
                )}

                <div className={`max-w-[85%] sm:max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                  isUser
                    ? 'bg-fuchsia-600 text-white rounded-br-none shadow-md'
                    : 'bg-slate-900/90 text-slate-200 border border-slate-800 rounded-tl-none shadow-sm'
                }`}>
                  <div className="whitespace-pre-wrap space-y-1">
                    {msg.text.split('\n').map((line, idx) => {
                      if (line.startsWith('### ')) {
                        return <h4 key={idx} className="font-bold text-white text-sm mt-1">{line.replace('### ', '')}</h4>;
                      }
                      if (line.startsWith('* ')) {
                        return <p key={idx} className="text-xs text-slate-300 pl-2">🔹 {line.replace('* ', '')}</p>;
                      }
                      return <p key={idx}>{line}</p>;
                    })}
                  </div>

                  {/* Render matched events inside AI chat bubble */}
                  {msg.matchedEvents && msg.matchedEvents.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-slate-800/80 space-y-2">
                      <p className="text-[11px] font-bold uppercase tracking-wider text-fuchsia-400">
                        Recommended Shows ({msg.matchedEvents.length})
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {msg.matchedEvents.map((evt) => (
                          <div
                            key={evt._id}
                            className="flex items-center gap-2.5 p-2 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-fuchsia-500/50 transition-all group"
                          >
                            <img
                              src={evt.bannerUrl || evt.posterUrl}
                              alt={evt.title}
                              className="w-12 h-12 rounded-lg object-cover bg-slate-800 shrink-0"
                            />
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-bold text-white truncate group-hover:text-fuchsia-400 transition-colors">
                                {evt.title}
                              </p>
                              <p className="text-[10px] text-slate-400 truncate">{evt.city} • {evt.venueName}</p>
                              <Link
                                to={`/event/${evt._id}`}
                                onClick={onClose}
                                className="inline-flex items-center gap-1 text-[10px] font-bold text-fuchsia-400 hover:text-fuchsia-300 mt-0.5"
                              >
                                <span>Book Tickets</span>
                                <ChevronRight className="w-3 h-3" />
                              </Link>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Render Suggested Followups */}
                  {msg.suggestedFollowUps && msg.suggestedFollowUps.length > 0 && (
                    <div className="mt-3 pt-2 border-t border-slate-800/60 flex flex-wrap gap-1.5">
                      {msg.suggestedFollowUps.map((prompt, pIdx) => (
                        <button
                          key={pIdx}
                          onClick={() => handleSendMessage(prompt)}
                          className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-fuchsia-950 hover:text-fuchsia-300 hover:border-fuchsia-500/40 border border-slate-700/80 text-slate-300 transition-all text-left"
                        >
                          💬 {prompt}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0 mt-0.5">
                    <User className="w-4 h-4 text-slate-300" />
                  </div>
                )}
              </div>
            );
          })}

          {loading && (
            <div className="flex gap-3 items-center text-xs text-slate-400">
              <div className="w-8 h-8 rounded-xl bg-fuchsia-600/30 border border-fuchsia-500/40 flex items-center justify-center">
                <RefreshCw className="w-4 h-4 text-fuchsia-400 animate-spin" />
              </div>
              <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-fuchsia-400 animate-bounce" />
                <span className="h-2 w-2 rounded-full bg-fuchsia-400 animate-bounce [animation-delay:0.2s]" />
                <span className="h-2 w-2 rounded-full bg-fuchsia-400 animate-bounce [animation-delay:0.4s]" />
                <span className="text-slate-400 text-xs ml-1">Analyzing knowledge base & shows...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-3 sm:p-4 bg-slate-950/90 border-t border-slate-800/80">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              placeholder="Ask anything (e.g. 'Concerts in Mumbai', 'Refund policy', 'Seat tiers')..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              disabled={loading}
              className="flex-1 bg-slate-900 text-sm text-slate-100 placeholder:text-slate-500 px-4 py-2.5 rounded-xl border border-slate-700 focus:outline-none focus:border-fuchsia-500 focus:ring-1 focus:ring-fuchsia-500 disabled:opacity-50 transition-all"
            />
            <button
              type="submit"
              disabled={!inputValue.trim() || loading}
              className="p-2.5 rounded-xl bg-fuchsia-600 hover:bg-fuchsia-500 text-white disabled:opacity-40 disabled:hover:bg-fuchsia-600 shadow-md shadow-fuchsia-600/20 transition-all"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
