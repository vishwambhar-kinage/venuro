import { dataStore } from '../models/dataStore.js';

export const getAllEvents = async (req, res) => {
  try {
    const { category, city, search, status } = req.query;
    const events = dataStore.getAllEvents({ category, city, search, status: status || 'active' });

    res.json({
      success: true,
      count: events.length,
      events
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

export const getEventById = async (req, res) => {
  try {
    const { id } = req.params;
    const event = dataStore.findEventById(id);

    if (!event) {
      return res.status(404).json({ success: false, message: 'Event not found' });
    }

    const shows = dataStore.getShowsForEvent(event._id);
    const reviews = dataStore.getReviewsForEvent(event._id);

    res.json({
      success: true,
      event,
      shows,
      reviews
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

export const createEvent = async (req, res) => {
  try {
    const eventData = {
      ...req.body,
      coordinatorId: req.user._id,
      status: req.user.role === 'admin' ? 'active' : 'active' // auto-active for demo ease
    };

    if (!eventData.title || !eventData.category || !eventData.city || !eventData.venueName) {
      return res.status(400).json({
        success: false,
        message: 'Please provide required event details (title, category, city, venueName).'
      });
    }

    const newEvent = dataStore.createEvent(eventData);

    // Auto-create default shows for the new event
    const today = new Date().toISOString().split('T')[0];
    dataStore.createShow({
      eventId: newEvent._id,
      screenName: 'Audi 1 - Dolby Atmos & Laser 4K',
      date: today,
      startTime: '19:30',
      endTime: '22:00'
    });

    res.status(201).json({
      success: true,
      message: 'Event created successfully!',
      event: newEvent
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

export const updateEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const event = dataStore.findEventById(id);

    if (!event) {
      return res.status(404).json({ success: false, message: 'Event not found' });
    }

    // Role check: Admin or coordinator who owns the event
    if (req.user.role !== 'admin' && event.coordinatorId !== req.user._id) {
      return res.status(403).json({ success: false, message: 'You can only edit your own events.' });
    }

    const updated = dataStore.updateEvent(id, req.body);

    res.json({
      success: true,
      message: 'Event updated successfully',
      event: updated
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

export const deleteEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const event = dataStore.findEventById(id);

    if (!event) {
      return res.status(404).json({ success: false, message: 'Event not found' });
    }

    if (req.user.role !== 'admin' && event.coordinatorId !== req.user._id) {
      return res.status(403).json({ success: false, message: 'Forbidden' });
    }

    dataStore.deleteEvent(id);

    res.json({
      success: true,
      message: 'Event deleted successfully'
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

export const getCoordinatorEvents = async (req, res) => {
  try {
    const coordinatorId = req.user._id;
    const events = dataStore.events.filter(e => e.coordinatorId === coordinatorId);
    
    // Attach booking count and revenue
    const allBookings = dataStore.getAllBookings();
    const enriched = events.map(evt => {
      const evtBookings = allBookings.filter(b => b.eventId === evt._id && b.bookingStatus === 'CONFIRMED');
      const ticketsSold = evtBookings.reduce((acc, b) => acc + (b.seats ? b.seats.length : 0), 0);
      const revenue = evtBookings.reduce((acc, b) => acc + (b.finalAmount || 0), 0);
      return {
        ...evt,
        ticketsSold,
        revenue,
        bookingsCount: evtBookings.length
      };
    });

    res.json({
      success: true,
      events: enriched
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
