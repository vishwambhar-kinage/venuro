import express from 'express';
import {
  getPlatformAnalytics,
  getAllUsers,
  updateUserRole,
  moderateEvent,
  getSystemHealth
} from '../controllers/adminController.js';
import { requireAuth } from '../middleware/authMiddleware.js';
import { authorizeRoles } from '../middleware/roleMiddleware.js';

const router = express.Router();

// Admin only routes
router.use(requireAuth, authorizeRoles('admin'));

router.get('/analytics', getPlatformAnalytics);
router.get('/users', getAllUsers);
router.put('/users/:userId/role', updateUserRole);
router.put('/events/:eventId/moderate', moderateEvent);
router.get('/health', getSystemHealth);

export default router;
