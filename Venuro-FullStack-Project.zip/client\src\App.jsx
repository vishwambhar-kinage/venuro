import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { AiAssistantModal } from './components/AiAssistantModal';

// Pages
import { HomePage } from './pages/HomePage';
import { EventDetailsPage } from './pages/EventDetailsPage';
import { SeatBookingPage } from './pages/SeatBookingPage';
import { UserDashboardPage } from './pages/UserDashboardPage';
import { CoordinatorDashboardPage } from './pages/CoordinatorDashboardPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { AuthPage } from './pages/AuthPage';

// Protected Route wrappers
const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="py-32 flex justify-center items-center">
        <div className="w-8 h-8 border-2 border-fuchsia-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/auth" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user?.role)) {
    return <Navigate to="/" replace />;
  }

  return children;
};

export const App = () => {
  const [aiChatOpen, setAiChatOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-[#080c15] text-slate-100 font-sans selection:bg-fuchsia-500 selection:text-white">
      {/* Top Navbar */}
      <Navbar onOpenAiChat={() => setAiChatOpen(true)} />

      {/* Main Viewport */}
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<HomePage onOpenAiChat={() => setAiChatOpen(true)} />} />
          <Route path="/event/:id" element={<EventDetailsPage onOpenAiChat={() => setAiChatOpen(true)} />} />
          <Route path="/book/:showId" element={<SeatBookingPage />} />
          
          <Route
            path="/user-dashboard"
            element={
              <ProtectedRoute allowedRoles={['user', 'coordinator', 'admin']}>
                <UserDashboardPage />
              </ProtectedRoute>
            }
          />
          
          <Route
            path="/coordinator"
            element={
              <ProtectedRoute allowedRoles={['coordinator', 'admin']}>
                <CoordinatorDashboardPage />
              </ProtectedRoute>
            }
          />
          
          <Route
            path="/admin"
            element={
              <ProtectedRoute allowedRoles={['admin']}>
                <AdminDashboardPage />
              </ProtectedRoute>
            }
          />

          <Route path="/auth" element={<AuthPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

      {/* Global AI RAG Assistant Floating Modal */}
      <AiAssistantModal
        isOpen={aiChatOpen}
        onClose={() => setAiChatOpen(false)}
      />

      {/* Bottom Footer */}
      <Footer />
    </div>
  );
};
