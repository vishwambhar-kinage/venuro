import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Request interceptor to attach JWT auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('venuro_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for unified error parsing
api.interceptors.response.use(
  (response) => response.data,
  (error) => {
    const message = error.response?.data?.message || error.message || 'Something went wrong';
    return Promise.reject(new Error(message));
  }
);

export const authAPI = {
  login: (credentials) => api.post('/auth/login', credentials),
  register: (userData) => api.post('/auth/register', userData),
  demoLogin: (role) => api.post('/auth/demo-login', { role }),
  getMe: () => api.get('/auth/me'),
  updateProfile: (data) => api.put('/auth/profile', data)
};

export const eventAPI = {
  getAll: (params) => api.get('/events', { params }),
  getById: (id) => api.get(`/events/${id}`),
  create: (data) => api.post('/events', data),
  update: (id, data) => api.put(`/events/${id}`, data),
  delete: (id) => api.delete(`/events/${id}`),
  getCoordinatorEvents: () => api.get('/events/coordinator/my-events')
};

export const showAPI = {
  getShowsForEvent: (eventId) => api.get(`/shows/event/${eventId}`),
  getSeatMap: (showId) => api.get(`/shows/${showId}/seat-map`),
  createShow: (data) => api.post('/shows', data)
};

export const bookingAPI = {
  lockSeats: (showId, seatIds) => api.post('/bookings/lock-seats', { showId, seatIds }),
  releaseSeats: (showId, seatIds) => api.post('/bookings/release-seats', { showId, seatIds }),
  checkout: (bookingData) => api.post('/bookings/checkout', bookingData),
  getMyBookings: () => api.get('/bookings/my-bookings'),
  getById: (id) => api.get(`/bookings/${id}`),
  cancelBooking: (id, reason) => api.post(`/bookings/${id}/cancel`, { reason }),
  verifyQR: (qrPayload) => api.post('/bookings/verify-qr', { qrPayload })
};

export const aiAPI = {
  chat: (message, history) => api.post('/ai/chat', { message, history }),
  getRecommendations: () => api.get('/ai/recommendations'),
  getKnowledgeBase: () => api.get('/ai/knowledge-base')
};

export const adminAPI = {
  getAnalytics: () => api.get('/admin/analytics'),
  getUsers: () => api.get('/admin/users'),
  updateUserRole: (userId, role) => api.put(`/admin/users/${userId}/role`, { role }),
  moderateEvent: (eventId, status) => api.put(`/admin/events/${eventId}/moderate`, { status }),
  getHealth: () => api.get('/admin/health')
};

export default api;
