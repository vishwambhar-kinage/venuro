import { redisClient } from '../config/redis.js';

/**
 * Redis-Backed Seat Locking & Concurrency Control Service
 * Ensures strict atomicity to prevent race conditions and double bookings.
 */

export class RedisLockService {
  /**
   * Generates standard lock key for a specific seat in a show
   */
  static getLockKey(showId, seatId) {
    return `lock:show:${showId}:seat:${seatId}`;
  }

  /**
   * Attempts to atomically lock a list of seats for a user
   * @param {string} showId 
   * @param {Array<string>} seatIds 
   * @param {string} userId 
   * @param {number} ttlSeconds Default 300s (5 mins)
   * @returns {Promise<{ success: boolean, lockedSeats: Array<string>, failedSeats: Array<string>, message: string }>}
   */
  static async acquireSeatLocks(showId, seatIds, userId, ttlSeconds = 300) {
    if (!showId || !seatIds || !seatIds.length || !userId) {
      return { success: false, lockedSeats: [], failedSeats: [], message: 'Invalid lock parameters' };
    }

    const lockedSeats = [];
    const failedSeats = [];

    for (const seatId of seatIds) {
      const key = this.getLockKey(showId, seatId);
      const lockPayload = JSON.stringify({
        userId,
        showId,
        seatId,
        lockedAt: Date.now(),
        expiresAt: Date.now() + (ttlSeconds * 1000)
      });

      // Try setting lock atomically with NX (Only if not exists) and EX (TTL)
      const res = await redisClient.set(key, lockPayload, 'NX', 'EX', ttlSeconds);

      if (res === 'OK') {
        lockedSeats.push(seatId);
      } else {
        // Seat already locked by another user or session
        // Check if it was locked by the SAME user
        const existingData = await redisClient.get(key);
        if (existingData) {
          try {
            const parsed = JSON.parse(existingData);
            if (parsed.userId === userId) {
              // Same user already holds this lock - refresh TTL
              await redisClient.set(key, lockPayload, 'EX', ttlSeconds);
              lockedSeats.push(seatId);
              continue;
            }
          } catch (e) {
            // parsing error
          }
        }
        failedSeats.push(seatId);
      }
    }

    // If ANY seat failed to lock in the batch, release all newly locked seats to keep operation atomic
    if (failedSeats.length > 0) {
      for (const seatId of lockedSeats) {
        const key = this.getLockKey(showId, seatId);
        await redisClient.del(key);
      }
      return {
        success: false,
        lockedSeats: [],
        failedSeats,
        message: `Seats [${failedSeats.join(', ')}] are currently held by other users. Please choose different seats.`
      };
    }

    return {
      success: true,
      lockedSeats,
      failedSeats: [],
      ttlSeconds,
      message: `Successfully locked ${lockedSeats.length} seats for ${ttlSeconds / 60} minutes.`
    };
  }

  /**
   * Releases temporary seat locks held by a user
   */
  static async releaseSeatLocks(showId, seatIds, userId) {
    if (!showId || !seatIds || !seatIds.length) return { released: [] };

    const released = [];
    for (const seatId of seatIds) {
      const key = this.getLockKey(showId, seatId);
      const existingData = await redisClient.get(key);

      if (existingData) {
        try {
          const parsed = JSON.parse(existingData);
          if (!userId || parsed.userId === userId) {
            await redisClient.del(key);
            released.push(seatId);
          }
        } catch (e) {
          await redisClient.del(key);
          released.push(seatId);
        }
      }
    }

    return { released };
  }

  /**
   * Retrieves all currently active locked seats for a showtime
   */
  static async getActiveLocksForShow(showId) {
    const pattern = `lock:show:${showId}:seat:*`;
    const keys = await redisClient.keys(pattern);
    const lockedMap = {};

    for (const key of keys) {
      const dataStr = await redisClient.get(key);
      const remainingTtl = await redisClient.ttl(key);
      if (dataStr) {
        try {
          const parsed = JSON.parse(dataStr);
          lockedMap[parsed.seatId] = {
            userId: parsed.userId,
            remainingSeconds: remainingTtl > 0 ? remainingTtl : 0
          };
        } catch (e) {}
      }
    }

    return lockedMap;
  }
}
