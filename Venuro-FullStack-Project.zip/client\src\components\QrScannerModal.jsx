import React, { useState } from 'react';
import { 
  X, 
  ScanLine, 
  CheckCircle2, 
  XCircle, 
  ShieldCheck, 
  ShieldAlert, 
  Ticket, 
  Calendar, 
  Clock, 
  MapPin,
  RefreshCw
} from 'lucide-react';
import { bookingAPI } from '../services/api';

export const QrScannerModal = ({ isOpen, onClose }) => {
  const [qrJsonInput, setQrJsonInput] = useState('');
  const [verifying, setVerifying] = useState(false);
  const [scanResult, setScanResult] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleVerifyPayload = async (payloadToVerify) => {
    setVerifying(true);
    setScanResult(null);
    setErrorMsg('');

    try {
      let parsed = null;
      if (typeof payloadToVerify === 'string') {
        try {
          parsed = JSON.parse(payloadToVerify);
        } catch (e) {
          throw new Error('Invalid QR payload format. Please input valid ticket JSON data.');
        }
      } else {
        parsed = payloadToVerify;
      }

      const res = await bookingAPI.verifyQR(parsed);
      if (res.success && res.ticket) {
        setScanResult({
          valid: true,
          status: res.status,
          message: res.message,
          ticket: res.ticket
        });
      }
    } catch (err) {
      setErrorMsg(err.message || 'QR Verification failed. Signature invalid or ticket forged.');
      setScanResult({
        valid: false,
        message: err.message
      });
    } finally {
      setVerifying(false);
    }
  };

  const handleQuickDemoScan = () => {
    // Fill in a sample valid ticket payload for coordinator demonstration
    const samplePayload = {
      bookingId: 'bkg_demo_sample_1',
      bookingNumber: 'VNR-89421-2026',
      eventTitle: 'Dune: Part Two (IMAX 3D Laser)',
      venue: 'PVR INOX IMAX Laser, Palladium Lower Parel',
      date: new Date().toISOString().split('T')[0],
      time: '19:45',
      seats: ['C5', 'C6'],
      totalAmount: 1870
    };
    // Let backend verify
    setQrJsonInput(JSON.stringify(samplePayload, null, 2));
    handleVerifyPayload(samplePayload);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-lg glass-dropdown rounded-3xl border border-amber-500/40 shadow-2xl shadow-amber-950/40 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-amber-950/80 to-slate-900/90 border-b border-amber-500/20 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30">
              <ScanLine className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Gate Admission QR Scanner</h3>
              <p className="text-xs text-amber-400/80">Coordinator & Admin Ticket Verification</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-xl">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-5">
          {/* Scanner Optical Simulation Viewport */}
          <div className="relative rounded-2xl bg-slate-950 border-2 border-dashed border-amber-500/40 p-6 flex flex-col items-center justify-center text-center overflow-hidden">
            <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-transparent via-amber-400 to-transparent animate-bounce" />
            <ScanLine className="w-12 h-12 text-amber-400 mb-2 opacity-80" />
            <p className="text-xs font-bold text-white">Live Optical Scanner Active</p>
            <p className="text-[11px] text-slate-400 max-w-xs mt-1">
              Point camera at guest QR pass or paste raw ticket QR payload below for instant HMAC signature validation.
            </p>

            <button
              onClick={handleQuickDemoScan}
              className="mt-4 px-4 py-2 rounded-xl text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/30 transition-all flex items-center gap-1.5"
            >
              <Ticket className="w-3.5 h-3.5" />
              <span>Simulate Guest QR Scan (Demo Pass)</span>
            </button>
          </div>

          {/* Manual / Pasted QR Payload input */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">
              Raw QR Code JSON Payload
            </label>
            <textarea
              rows={3}
              placeholder='{"bookingId": "bkg_...", "signature": "..."}'
              value={qrJsonInput}
              onChange={(e) => setQrJsonInput(e.target.value)}
              className="w-full bg-slate-900 text-xs text-slate-200 p-3 rounded-xl border border-slate-700 font-mono focus:outline-none focus:border-amber-500"
            />
            <button
              onClick={() => handleVerifyPayload(qrJsonInput)}
              disabled={!qrJsonInput.trim() || verifying}
              className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            >
              {verifying ? (
                <span className="flex items-center gap-2 text-white">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  Verifying Cryptographic Signature...
                </span>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Verify Gate Admission</span>
                </>
              )}
            </button>
          </div>

          {/* Validation Result Box */}
          {scanResult && (
            <div className={`p-4 rounded-2xl border transition-all animate-in zoom-in-95 duration-150 ${
              scanResult.valid
                ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-200'
                : 'bg-rose-950/70 border-rose-500/50 text-rose-200'
            }`}>
              <div className="flex items-center gap-2.5 mb-2">
                {scanResult.valid ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                ) : (
                  <XCircle className="w-5 h-5 text-rose-400" />
                )}
                <span className="font-bold text-sm">
                  {scanResult.valid ? 'ADMISSION GRANTED' : 'ADMISSION DENIED'}
                </span>
              </div>
              <p className="text-xs opacity-90">{scanResult.message}</p>

              {scanResult.valid && scanResult.ticket && (
                <div className="mt-3 pt-3 border-t border-emerald-800/60 grid grid-cols-2 gap-2 text-[11px] text-slate-200">
                  <div>
                    <span className="text-emerald-400 block font-semibold">Event</span>
                    <span className="font-bold">{scanResult.ticket.eventTitle}</span>
                  </div>
                  <div>
                    <span className="text-emerald-400 block font-semibold">Seats ({scanResult.ticket.admitCount})</span>
                    <span className="font-mono font-bold text-white">{scanResult.ticket.seats.join(', ')}</span>
                  </div>
                  <div>
                    <span className="text-emerald-400 block font-semibold">Booking ID</span>
                    <span className="font-mono">{scanResult.ticket.bookingNumber}</span>
                  </div>
                  <div>
                    <span className="text-emerald-400 block font-semibold">Show Date/Time</span>
                    <span>{scanResult.ticket.date} @ {scanResult.ticket.time}</span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
