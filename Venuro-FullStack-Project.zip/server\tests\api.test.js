import { test, describe, before } from 'node:test';
import assert from 'node:assert';
import { seedInitialData } from '../src/utils/seedData.js';
import { dataStore } from '../src/models/dataStore.js';
import { RedisLockService } from '../src/services/redisLockService.js';
import { QRService } from '../src/services/qrService.js';
import { RAGService } from '../src/services/ragService.js';
import { generateToken } from '../src/middleware/authMiddleware.js';

describe('🎟️ Venuro Enterprise Test Suite', () => {
  before(async () => {
    await seedInitialData();
  });

  describe('1. Authentication & Role Based Access', () => {
    test('Should have seeded user, coordinator, and admin demo accounts', () => {
      const user = dataStore.findUserByEmail('user@venuro.com');
      const coordinator = dataStore.findUserByEmail('coordinator@venuro.com');
      const admin = dataStore.findUserByEmail('admin@venuro.com');

      assert.ok(user, 'User account should exist');
      assert.strictEqual(user.role, 'user');

      assert.ok(coordinator, 'Coordinator account should exist');
      assert.strictEqual(coordinator.role, 'coordinator');

      assert.ok(admin, 'Admin account should exist');
      assert.strictEqual(admin.role, 'admin');
    });

    test('Should successfully generate and sign valid JWT token', () => {
      const user = dataStore.findUserByEmail('user@venuro.com');
      const token = generateToken(user);
      assert.ok(token, 'JWT Token must be generated');
      assert.ok(typeof token === 'string');
    });
  });

  describe('2. Event Catalog & Discovery', () => {
    test('Should return all active events across categories', () => {
      const allEvents = dataStore.getAllEvents({ status: 'active' });
      assert.ok(allEvents.length >= 5, 'Should have at least 5 seeded events');
    });

    test('Should filter events by category (e.g. concerts)', () => {
      const concerts = dataStore.getAllEvents({ category: 'concerts' });
      assert.ok(concerts.length > 0);
      assert.ok(concerts.every(e => e.category === 'concerts'));
    });
  });

  describe('3. Redis-Backed Concurrency & Temporary Seat Locking', () => {
    test('User A should acquire atomic lock for seats A1, A2 for 300s', async () => {
      const showId = 'shw_dune2_1';
      const seatIds = ['A1', 'A2'];
      const userId = 'usr_normal_1';

      const lockRes = await RedisLockService.acquireSeatLocks(showId, seatIds, userId, 300);
      assert.strictEqual(lockRes.success, true);
      assert.deepStrictEqual(lockRes.lockedSeats, ['A1', 'A2']);
    });

    test('User B attempting to lock seat A1 should be REJECTED (Zero Double Booking)', async () => {
      const showId = 'shw_dune2_1';
      const seatIds = ['A1', 'A3'];
      const userB = 'usr_another_2';

      const lockRes = await RedisLockService.acquireSeatLocks(showId, seatIds, userB, 300);
      assert.strictEqual(lockRes.success, false);
      assert.ok(lockRes.failedSeats.includes('A1'));
    });

    test('User A releasing seat locks should free seats immediately', async () => {
      const showId = 'shw_dune2_1';
      const seatIds = ['A1', 'A2'];
      const userId = 'usr_normal_1';

      const releaseRes = await RedisLockService.releaseSeatLocks(showId, seatIds, userId);
      assert.ok(releaseRes.released.includes('A1'));
      assert.ok(releaseRes.released.includes('A2'));

      // User B should now be able to acquire lock
      const lockRes = await RedisLockService.acquireSeatLocks(showId, ['A1'], 'usr_another_2', 300);
      assert.strictEqual(lockRes.success, true);
    });
  });

  describe('4. Cryptographic QR Tickets & HMAC Validation', () => {
    test('Should create and verify tamper-proof QR ticket payload', async () => {
      const sampleBooking = {
        _id: 'bkg_test_999',
        bookingNumber: 'VNR-TEST-1234',
        finalAmount: 1800,
        seats: [{ id: 'B1' }, { id: 'B2' }]
      };
      const sampleEvent = { title: 'Coldplay Stadium Tour', venueName: 'DY Patil Stadium' };
      const sampleShow = { date: '2026-09-10', startTime: '18:00' };

      const payload = QRService.createTicketPayload(sampleBooking, sampleEvent, sampleShow);
      assert.ok(payload.signature, 'Payload must contain HMAC signature');

      // Verify payload
      const verifyResult = QRService.verifyTicketPayload(payload);
      assert.strictEqual(verifyResult.valid, true);

      // Verify tampered payload fails
      const tampered = { ...payload, seats: ['VIP1', 'VIP2'] };
      const tamperedResult = QRService.verifyTicketPayload(tampered);
      assert.strictEqual(tamperedResult.valid, false);
    });
  });

  describe('5. AI-Powered RAG Assistant & Vector Search', () => {
    test('Should answer refund policy queries with domain knowledge', async () => {
      const query = 'Can I get a refund if I cancel my ticket?';
      const aiResponse = await RAGService.askAiAssistant(query);

      assert.strictEqual(aiResponse.intent, 'refund_policy');
      assert.ok(aiResponse.answer.includes('100%'));
      assert.ok(aiResponse.answer.includes('24 hours'));
    });

    test('Should discover relevant events matching natural language query', async () => {
      const query = 'Find Coldplay concerts in Mumbai';
      const aiResponse = await RAGService.askAiAssistant(query);

      assert.ok(aiResponse.matchedEvents.length > 0);
      assert.ok(aiResponse.matchedEvents.some(e => e.title.includes('Coldplay')));
    });
  });
});
