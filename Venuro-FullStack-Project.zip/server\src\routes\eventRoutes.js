import express from 'express';
import {
  getAllEvents,
  getEventById,
  createEvent,
  updateEvent,
  deleteEvent,
  getCoordinatorEvents
} from '../controllers/eventController.js';
import { requireAuth } from '../middleware/authMiddleware.js';
import { authorizeRoles } from '../middleware/roleMiddleware.js';

const router = express.Router();

router.get('/', getAllEvents);
router.get('/coordinator/my-events', requireAuth, authorizeRoles('coordinator', 'admin'), getCoordinatorEvents);
router.get('/:id', getEventById);
router.post('/', requireAuth, authorizeRoles('coordinator', 'admin'), createEvent);
router.put('/:id', requireAuth, authorizeRoles('coordinator', 'admin'), updateEvent);
router.delete('/:id', requireAuth, authorizeRoles('coordinator', 'admin'), deleteEvent);

export default router;
