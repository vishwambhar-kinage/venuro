import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { 
  X, 
  CreditCard, 
  Smartphone, 
  Building2, 
  Wallet, 
  ShieldCheck, 
  Tag, 
  Lock, 
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { bookingAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';

export const CheckoutModal = ({
  isOpen,
  onClose,
  show,
  event,
  selectedSeats,
  onBookingSuccess
}) => {
  const { user, refreshUser } = useAuth();
  const [paymentMethod, setPaymentMethod] = useState('UPI');
  const [promoCode, setPromoCode] = useState('');
  const [promoApplied, setPromoApplied] = useState(false);
  const [discountAmount, setDiscountAmount] = useState(0);
  const [promoError, setPromoError] = useState('');
  const [processing, setProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const baseTotal = selectedSeats.reduce((sum, s) => sum + s.price, 0);
  const convenienceFee = selectedSeats.length * 35;
  const finalTotal = Math.max(0, baseTotal - discountAmount + convenienceFee);

  const handleApplyPromo = () => {
    setPromoError('');
    const code = promoCode.trim().toUpperCase();
    if (code === 'VENURO20') {
      const disc = Math.round(baseTotal * 0.20);
      setDiscountAmount(disc);
      setPromoApplied(true);
    } else if (code === 'FIRSTSHOW') {
      const disc = Math.min(150, Math.round(baseTotal * 0.50));
      setDiscountAmount(disc);
      setPromoApplied(true);
    } else {
      setPromoError('Invalid promo code. Try VENURO20 or FIRSTSHOW.');
    }
  };

  const handlePayAndConfirm = async () => {
    setProcessing(true);
    setErrorMsg('');

    try {
      const bookingData = {
        showId: show._id,
        seatIds: selectedSeats.map((s) => s.id),
        paymentMethod,
        promoCode: promoApplied ? promoCode : ''
      };

      const res = await bookingAPI.checkout(bookingData);

      if (res.success && res.booking) {
        // Trigger celebratory confetti
        confetti({
          particleCount: 120,
          spread: 80,
          origin: { y: 0.6 }
        });

        await refreshUser();
        onBookingSuccess(res.booking);
      }
    } catch (err) {
      setErrorMsg(err.message || 'Payment simulation failed. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-xl glass-dropdown rounded-3xl border border-slate-700/80 shadow-2xl shadow-fuchsia-950/40 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-white text-base">Confirm & Pay</h3>
            <p className="text-xs text-slate-400">{event.title} • {show.screenName}</p>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-xl">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5">
          {errorMsg && (
            <div className="p-3.5 rounded-xl bg-rose-950/80 border border-rose-500/50 flex items-center gap-2.5 text-xs text-rose-200">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Show summary */}
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
            <div>
              <p className="text-xs text-slate-400">Date & Showtime</p>
              <p className="text-sm font-bold text-white">{show.date} @ {show.startTime}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-400">Seats ({selectedSeats.length})</p>
              <p className="text-sm font-bold text-fuchsia-400 font-mono">
                {selectedSeats.map((s) => s.id).join(', ')}
              </p>
            </div>
          </div>

          {/* Promo code input */}
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1.5 flex items-center gap-1">
              <Tag className="w-3.5 h-3.5 text-fuchsia-400" />
              <span>Apply Promo Code</span>
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Enter coupon (e.g. VENURO20)"
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value)}
                disabled={promoApplied}
                className="flex-1 bg-slate-900 text-xs text-slate-200 px-3.5 py-2.5 rounded-xl border border-slate-700 focus:outline-none focus:border-fuchsia-500 uppercase placeholder:normal-case font-mono"
              />
              <button
                type="button"
                onClick={handleApplyPromo}
                disabled={promoApplied || !promoCode.trim()}
                className="px-4 py-2.5 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 disabled:opacity-50"
              >
                {promoApplied ? 'Applied' : 'Apply'}
              </button>
            </div>
            {promoApplied && (
              <p className="text-[11px] text-emerald-400 font-medium mt-1 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Coupon applied! Saved ₹{discountAmount}
              </p>
            )}
            {promoError && <p className="text-[11px] text-rose-400 mt-1">{promoError}</p>}
          </div>

          {/* Payment Method Selector */}
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-2">
              Select Payment Method
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {[
                { id: 'UPI', label: 'UPI / QR', icon: Smartphone },
                { id: 'CARD', label: 'Card', icon: CreditCard },
                { id: 'NETBANKING', label: 'Net Banking', icon: Building2 },
                { id: 'WALLET', label: 'Venuro Wallet', icon: Wallet },
              ].map((method) => {
                const Icon = method.icon;
                const isSelected = paymentMethod === method.id;
                return (
                  <button
                    key={method.id}
                    type="button"
                    onClick={() => setPaymentMethod(method.id)}
                    className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all ${
                      isSelected
                        ? 'bg-fuchsia-500/15 border-fuchsia-500 text-white shadow-md'
                        : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                    }`}
                  >
                    <Icon className={`w-4 h-4 mb-2 ${isSelected ? 'text-fuchsia-400' : 'text-slate-400'}`} />
                    <div>
                      <span className="text-xs font-bold block">{method.label}</span>
                      {method.id === 'WALLET' && (
                        <span className="text-[10px] text-emerald-400 block font-mono">₹{user?.walletBalance || 0}</span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Detailed Price Breakdown */}
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2 text-xs">
            <div className="flex justify-between text-slate-400">
              <span>Base Ticket Fare ({selectedSeats.length} seats)</span>
              <span className="font-mono text-slate-200">₹{baseTotal}</span>
            </div>
            {discountAmount > 0 && (
              <div className="flex justify-between text-emerald-400">
                <span>Promo Discount</span>
                <span className="font-mono">-₹{discountAmount}</span>
              </div>
            )}
            <div className="flex justify-between text-slate-400">
              <span>Convenience & Platform Fee</span>
              <span className="font-mono text-slate-200">₹{convenienceFee}</span>
            </div>
            <div className="border-t border-slate-800 pt-2 flex justify-between text-sm font-bold text-white">
              <span>Total Payable</span>
              <span className="text-fuchsia-400 font-mono text-base">₹{finalTotal}</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 sm:p-6 bg-slate-900/90 border-t border-slate-800 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <Lock className="w-3.5 h-3.5 text-emerald-400" />
            <span>256-Bit Encrypted Simulation</span>
          </div>

          <button
            onClick={handlePayAndConfirm}
            disabled={processing}
            className="px-6 py-3 rounded-xl font-bold text-sm bg-gradient-to-r from-fuchsia-600 to-indigo-600 hover:from-fuchsia-500 hover:to-indigo-500 text-white shadow-xl shadow-fuchsia-600/30 flex items-center gap-2 transition-all disabled:opacity-50"
          >
            {processing ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Generating Ticket...
              </span>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4" />
                <span>Simulate Payment (₹{finalTotal})</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
