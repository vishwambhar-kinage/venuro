import QRCode from 'qrcode';
import crypto from 'crypto';

const QR_SECRET = process.env.QR_SECRET || 'venuro-super-secret-qr-key-2026';

export class QRService {
  /**
   * Generates a digital QR ticket payload with integrity signature
   */
  static createTicketPayload(booking, event, show) {
    const dataString = `${booking._id}|${booking.bookingNumber}|${event.title}|${show.date}|${show.startTime}|${booking.seats.map(s => s.id).join(',')}`;
    const signature = crypto.createHmac('sha256', QR_SECRET).update(dataString).digest('hex').substring(0, 16);

    return {
      bookingId: booking._id,
      bookingNumber: booking.bookingNumber,
      eventTitle: event.title,
      venue: event.venueName,
      date: show.date,
      time: show.startTime,
      seats: booking.seats.map(s => s.id),
      totalAmount: booking.finalAmount,
      signature
    };
  }

  /**
   * Generates Base64 Data URL for the QR code
   */
  static async generateQRCodeDataUrl(payload) {
    try {
      const jsonString = JSON.stringify(payload);
      const dataUrl = await QRCode.toDataURL(jsonString, {
        errorCorrectionLevel: 'H',
        type: 'image/png',
        margin: 2,
        width: 320,
        color: {
          dark: '#0f172a',
          light: '#ffffff'
        }
      });
      return dataUrl;
    } catch (err) {
      console.error('Error generating QR Code:', err);
      return null;
    }
  }

  /**
   * Verifies scanned QR code payload integrity
   */
  static verifyTicketPayload(payload) {
    if (!payload || !payload.bookingId || !payload.signature) {
      return { valid: false, message: 'Malformed ticket QR payload' };
    }

    const dataString = `${payload.bookingId}|${payload.bookingNumber}|${payload.eventTitle}|${payload.date}|${payload.time}|${payload.seats.join(',')}`;
    const expectedSig = crypto.createHmac('sha256', QR_SECRET).update(dataString).digest('hex').substring(0, 16);

    if (expectedSig !== payload.signature) {
      return { valid: false, message: 'Digital signature mismatch: Invalid or forged ticket!' };
    }

    return { valid: true, payload };
  }
}
