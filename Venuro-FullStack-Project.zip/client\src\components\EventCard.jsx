import React from 'react';
import { Link } from 'react-router-dom';
import { Star, MapPin, Calendar, Clock, Ticket } from 'lucide-react';

export const EventCard = ({ event }) => {
  const getCategoryColor = (cat) => {
    switch (cat?.toLowerCase()) {
      case 'movies':
        return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'concerts':
        return 'bg-fuchsia-500/20 text-fuchsia-400 border-fuchsia-500/30';
      case 'sports':
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
      case 'live-shows':
        return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
      case 'experiences':
        return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      default:
        return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
    }
  };

  return (
    <div className="group relative flex flex-col rounded-2xl overflow-hidden glass-card transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl">
      {/* Poster Image & Category Pill */}
      <div className="relative aspect-[16/10] overflow-hidden bg-slate-900">
        <img
          src={event.bannerUrl || event.posterUrl}
          alt={event.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />
        
        {/* Category Pill */}
        <span className={`absolute top-3 left-3 text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg backdrop-blur-md border ${getCategoryColor(event.category)}`}>
          {event.category}
        </span>

        {/* Rating Badge */}
        <div className="absolute top-3 right-3 flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-900/80 backdrop-blur-md border border-slate-700/80 text-yellow-400 text-xs font-bold shadow-md">
          <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
          <span>{event.rating || '4.9'}</span>
        </div>

        {/* City & Language overlay */}
        <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-xs text-slate-300">
          <span className="flex items-center gap-1 truncate font-medium">
            <MapPin className="w-3.5 h-3.5 text-fuchsia-400 shrink-0" />
            {event.city}
          </span>
          <span className="text-[11px] text-slate-400 bg-slate-900/60 px-2 py-0.5 rounded-md backdrop-blur-sm">
            {event.language || 'English'}
          </span>
        </div>
      </div>

      {/* Content Area */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
        <div>
          <h3 className="font-bold text-base text-white line-clamp-1 group-hover:text-fuchsia-400 transition-colors">
            {event.title}
          </h3>
          <p className="text-xs text-slate-400 line-clamp-2 mt-1 leading-relaxed">
            {event.description}
          </p>
        </div>

        {/* Tags / Genres */}
        <div className="flex flex-wrap gap-1.5 pt-1">
          {event.genre?.slice(0, 3).map((g, idx) => (
            <span key={idx} className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700/60">
              {g}
            </span>
          ))}
        </div>

        {/* Footer info & CTA */}
        <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2">
          <div>
            <span className="text-[10px] uppercase tracking-wider text-slate-400 block font-semibold">Venue</span>
            <span className="text-xs font-medium text-slate-300 truncate max-w-[140px] block">{event.venueName}</span>
          </div>

          <Link
            to={`/event/${event._id}`}
            className="inline-flex items-center gap-1 px-3.5 py-2 rounded-xl text-xs font-bold bg-fuchsia-600 hover:bg-fuchsia-500 text-white shadow-lg shadow-fuchsia-600/20 hover:shadow-fuchsia-600/40 transition-all"
          >
            <Ticket className="w-3.5 h-3.5" />
            <span>Book</span>
          </Link>
        </div>
      </div>
    </div>
  );
};
