import express from 'express';
import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import dotenv from 'dotenv';

import { connectDB } from './config/db.js';
import { seedInitialData } from './utils/seedData.js';
import { errorHandler } from './middleware/errorHandler.js';

// Route imports
import authRoutes from './routes/authRoutes.js';
import eventRoutes from './routes/eventRoutes.js';
import showRoutes from './routes/showRoutes.js';
import bookingRoutes from './routes/bookingRoutes.js';
import aiRoutes from './routes/aiRoutes.js';
import adminRoutes from './routes/adminRoutes.js';

dotenv.config();

const app = express();
const server = http.createServer(app);

// Initialize Socket.io with permissive CORS for development & container environments
export const io = new SocketIOServer(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// Middleware configuration
app.use(helmet({
  crossOriginResourcePolicy: false
}));
app.use(cors({
  origin: '*',
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(morgan('dev'));

// Socket.io Real-Time Connection Handling
io.on('connection', (socket) => {
  console.log(`🔌 [Socket.io] Client connected: ${socket.id}`);

  // User joins a specific showtime seat map room
  socket.on('join_show', (showId) => {
    socket.join(`show_${showId}`);
    console.log(`📡 [Socket.io] Socket ${socket.id} joined show room: show_${showId}`);
  });

  // User leaves show room
  socket.on('leave_show', (showId) => {
    socket.leave(`show_${showId}`);
    console.log(`🚪 [Socket.io] Socket ${socket.id} left show room: show_${showId}`);
  });

  socket.on('disconnect', () => {
    console.log(`🔌 [Socket.io] Client disconnected: ${socket.id}`);
  });
});

// Health check route
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    app: 'Venuro Platform API',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/events', eventRoutes);
app.use('/api/shows', showRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/admin', adminRoutes);

// Global Error Handler
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

const startServer = async () => {
  try {
    await connectDB();
    await seedInitialData();

    server.listen(PORT, () => {
      console.log(`\n======================================================`);
      console.log(`🎟️  VENURO API SERVER IS RUNNING ON PORT ${PORT}`);
      console.log(`🌐  API URL: http://localhost:${PORT}/api`);
      console.log(`🤖  AI RAG & Redis Locking Engine: ACTIVE`);
      console.log(`======================================================\n`);
    });
  } catch (error) {
    console.error('Failed to start Venuro server:', error);
    process.exit(1);
  }
};

startServer();
