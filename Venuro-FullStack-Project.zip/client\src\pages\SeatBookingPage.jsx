import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  Sparkles, 
  ShieldCheck, 
  Timer, 
  MapPin, 
  Calendar, 
  Clock,
  AlertCircle
} from 'lucide-react';
import { showAPI, bookingAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import { SeatMatrix } from '../components/SeatMatrix';
import { CheckoutModal } from '../components/CheckoutModal';
import { DigitalTicketModal } from '../components/DigitalTicketModal';

export const SeatBookingPage = () => {
  const { showId } = useParams();
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const { socket } = useSocket();

  const [show, setShow] = useState(null);
  const [event, setEvent] = useState(null);
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [lockingLoading, setLockingLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Lock state
  const [isLockedByMe, setIsLockedByMe] = useState(false);
  const [lockSecondsRemaining, setLockSecondsRemaining] = useState(0);

  // Modals
  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);
  const [ticketModalOpen, setTicketModalOpen] = useState(false);
  const [confirmedBooking, setConfirmedBooking] = useState(null);

  // Fetch initial seat matrix
  useEffect(() => {
    fetchSeatData();
  }, [showId]);

  // Real-time socket room synchronization
  useEffect(() => {
    if (!socket || !showId) return;

    socket.emit('join_show', showId);

    const handleSeatsUpdated = (data) => {
      console.log('📡 [Live Seat Broadcast]:', data);
      // Refresh seat grid overlay
      fetchSeatData(false);
    };

    socket.on('seats_updated', handleSeatsUpdated);

    return () => {
      socket.emit('leave_show', showId);
      socket.off('seats_updated', handleSeatsUpdated);
    };
  }, [socket, showId]);

  // Lock countdown timer
  useEffect(() => {
    let interval = null;
    if (isLockedByMe && lockSecondsRemaining > 0) {
      interval = setInterval(() => {
        setLockSecondsRemaining((prev) => {
          if (prev <= 1) {
            // Lock expired!
            setIsLockedByMe(false);
            setSelectedSeats([]);
            setCheckoutModalOpen(false);
            setErrorMsg('Your 5-minute temporary seat lock has expired. Please select seats again.');
            fetchSeatData(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isLockedByMe, lockSecondsRemaining]);

  const fetchSeatData = async (showSpinner = true) => {
    if (showSpinner) setLoading(true);
    try {
      const res = await showAPI.getSeatMap(showId);
      if (res.success) {
        setShow(res.show);
        setEvent(res.event);
      }
    } catch (err) {
      setErrorMsg(err.message || 'Failed to load seat layout.');
    } finally {
      if (showSpinner) setLoading(false);
    }
  };

  const handleToggleSeat = (seat) => {
    setErrorMsg('');
    const exists = selectedSeats.some((s) => s.id === seat.id);
    if (exists) {
      setSelectedSeats(selectedSeats.filter((s) => s.id !== seat.id));
      if (isLockedByMe) {
        // Release lock for that seat
        bookingAPI.releaseSeats(showId, [seat.id]).catch(() => {});
      }
    } else {
      if (selectedSeats.length >= 8) {
        setErrorMsg('You can select a maximum of 8 seats per booking.');
        return;
      }
      setSelectedSeats([...selectedSeats, seat]);
    }
  };

  const handleProceedToLockAndCheckout = async () => {
    if (!isAuthenticated) {
      navigate('/auth?redirect=' + encodeURIComponent(`/book/${showId}`));
      return;
    }

    if (selectedSeats.length === 0) {
      setErrorMsg('Please select at least 1 seat to proceed.');
      return;
    }

    setLockingLoading(true);
    setErrorMsg('');

    try {
      const res = await bookingAPI.lockSeats(
        showId,
        selectedSeats.map((s) => s.id)
      );

      if (res.success) {
        setIsLockedByMe(true);
        setLockSecondsRemaining(res.ttlSeconds || 300);
        setCheckoutModalOpen(true);
      }
    } catch (err) {
      setErrorMsg(err.message || 'Could not acquire temporary lock for seats. Please try different seats.');
      fetchSeatData(false);
    } finally {
      setLockingLoading(false);
    }
  };

  const handleBookingSuccess = (newBooking) => {
    setConfirmedBooking(newBooking);
    setCheckoutModalOpen(false);
    setIsLockedByMe(false);
    setLockSecondsRemaining(0);
    setSelectedSeats([]);
    setTicketModalOpen(true);
    fetchSeatData(false);
  };

  if (loading) {
    return (
      <div className="py-32 flex flex-col items-center justify-center text-slate-400 space-y-3">
        <div className="w-10 h-10 border-2 border-fuchsia-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-sm font-semibold">Connecting to live seat matrix & Redis lock engine...</p>
      </div>
    );
  }

  if (!show || !event) {
    return (
      <div className="max-w-xl mx-auto py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold text-white">Showtime Not Found</h2>
        <Link to="/" className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-fuchsia-600 text-white text-xs font-bold">
          <ArrowLeft className="w-4 h-4" /> Back to Home
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 pb-24">
      {/* Top Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 glass-panel p-4 sm:p-5 rounded-3xl border border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate(`/event/${event._id}`)}
            className="p-2 rounded-xl bg-slate-900 text-slate-400 hover:text-white border border-slate-800 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="font-extrabold text-white text-base sm:text-lg">{event.title}</h1>
            <p className="text-xs text-slate-400 flex items-center gap-2">
              <span>{show.screenName}</span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Calendar className="w-3 h-3 text-fuchsia-400" />
                {show.date}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3 text-fuchsia-400" />
                {show.startTime}
              </span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5 font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Live Sync Active
          </span>
        </div>
      </div>

      {/* Error alert */}
      {errorMsg && (
        <div className="p-4 rounded-2xl bg-rose-950/80 border border-rose-500/50 flex items-center gap-3 text-xs text-rose-200 animate-in fade-in">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Interactive Seat Matrix Component */}
      <SeatMatrix
        show={show}
        event={event}
        selectedSeats={selectedSeats}
        onToggleSeat={handleToggleSeat}
        isLockedByMe={isLockedByMe}
        lockSecondsRemaining={lockSecondsRemaining}
        onProceedCheckout={handleProceedToLockAndCheckout}
        lockingLoading={lockingLoading}
      />

      {/* Checkout Modal */}
      {checkoutModalOpen && (
        <CheckoutModal
          isOpen={checkoutModalOpen}
          onClose={() => setCheckoutModalOpen(false)}
          show={show}
          event={event}
          selectedSeats={selectedSeats}
          onBookingSuccess={handleBookingSuccess}
        />
      )}

      {/* Digital Ticket Modal */}
      {ticketModalOpen && confirmedBooking && (
        <DigitalTicketModal
          isOpen={ticketModalOpen}
          onClose={() => setTicketModalOpen(false)}
          booking={confirmedBooking}
        />
      )}
    </div>
  );
};
