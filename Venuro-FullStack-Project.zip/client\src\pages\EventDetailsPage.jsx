import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  Star, 
  MapPin, 
  Clock, 
  Calendar, 
  Ticket, 
  Users, 
  ShieldCheck, 
  AlertCircle, 
  ChevronRight, 
  MessageSquare,
  Sparkles,
  ArrowLeft
} from 'lucide-react';
import { eventAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';

export const EventDetailsPage = ({ onOpenAiChat }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [event, setEvent] = useState(null);
  const [shows, setShows] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState('');

  useEffect(() => {
    fetchEventDetails();
  }, [id]);

  const fetchEventDetails = async () => {
    setLoading(true);
    try {
      const res = await eventAPI.getById(id);
      if (res.success) {
        setEvent(res.event);
        setShows(res.shows || []);
        setReviews(res.reviews || []);

        if (res.shows && res.shows.length > 0) {
          setSelectedDate(res.shows[0].date);
        }
      }
    } catch (err) {
      console.error('Failed to load event details:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="py-32 flex flex-col items-center justify-center text-slate-400 space-y-3">
        <div className="w-10 h-10 border-2 border-fuchsia-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-sm font-semibold">Loading showtimes and experience details...</p>
      </div>
    );
  }

  if (!event) {
    return (
      <div className="max-w-xl mx-auto py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold text-white">Event Not Found</h2>
        <p className="text-xs text-slate-400">The event you are looking for does not exist or has concluded.</p>
        <Link to="/" className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-fuchsia-600 text-white text-xs font-bold">
          <ArrowLeft className="w-4 h-4" /> Back to Home
        </Link>
      </div>
    );
  }

  // Group shows by date
  const uniqueDates = Array.from(new Set(shows.map(s => s.date))).sort();
  const filteredShows = shows.filter(s => s.date === selectedDate);

  return (
    <div className="space-y-10 pb-20">
      {/* Banner & Hero Header */}
      <section className="relative -mt-4 sm:-mt-6">
        {/* Background Backdrop Image */}
        <div className="relative h-[320px] sm:h-[450px] w-full overflow-hidden">
          <img
            src={event.bannerUrl}
            alt={event.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#080c15] via-[#080c15]/75 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#080c15] via-transparent to-transparent" />
        </div>

        {/* Floating Content Card */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative -mt-36 sm:-mt-52 z-10">
          <div className="glass-panel rounded-3xl p-6 sm:p-8 border border-slate-700/80 shadow-2xl flex flex-col md:flex-row gap-6 sm:gap-8 items-start">
            {/* Poster thumbnail */}
            <img
              src={event.posterUrl || event.bannerUrl}
              alt={event.title}
              className="w-36 sm:w-52 aspect-[2/3] object-cover rounded-2xl shadow-2xl border-2 border-slate-700/80 shrink-0 mx-auto md:mx-0"
            />

            {/* Info */}
            <div className="flex-1 space-y-4 text-left">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-3 py-1 rounded-lg text-xs font-bold uppercase tracking-wider bg-fuchsia-600 text-white shadow-md">
                  {event.category}
                </span>
                <span className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                  {event.ageLimit || '13+'}
                </span>
                <span className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                  {event.language}
                </span>
              </div>

              <h1 className="text-2xl sm:text-4xl font-extrabold text-white font-['Space_Grotesk'] leading-tight">
                {event.title}
              </h1>

              {/* Badges & Meta */}
              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300">
                <div className="flex items-center gap-1 text-yellow-400 font-bold">
                  <Star className="w-4 h-4 fill-yellow-400" />
                  <span>{event.rating} / 5.0</span>
                  <span className="text-slate-400 font-normal">({event.totalReviews} reviews)</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4 text-fuchsia-400" />
                  <span>{event.duration}</span>
                </div>
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4 text-fuchsia-400" />
                  <span>{event.city}</span>
                </div>
              </div>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-3xl">
                {event.description}
              </p>

              {/* Genre Pills */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {event.genre?.map((g, idx) => (
                  <span key={idx} className="text-xs font-semibold px-3 py-1 rounded-lg bg-slate-900 text-fuchsia-300 border border-fuchsia-500/20">
                    {g}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Grid: Showtimes & Venue Details */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Showtime Selection */}
        <div className="lg:col-span-2 space-y-6">
          <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <h2 className="text-lg font-bold text-white font-['Space_Grotesk']">
                  Select Showtime & Screen
                </h2>
                <p className="text-xs text-slate-400">Choose your preferred date and slot to enter interactive seat matrix</p>
              </div>
              <button
                onClick={onOpenAiChat}
                className="hidden sm:inline-flex items-center gap-1.5 text-xs font-bold text-fuchsia-400 hover:text-fuchsia-300"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Ask AI best time</span>
              </button>
            </div>

            {/* Date Selection Tabs */}
            {uniqueDates.length > 0 ? (
              <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
                {uniqueDates.map((dateStr) => {
                  const isSelected = selectedDate === dateStr;
                  const d = new Date(dateStr);
                  const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
                  const monthDay = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

                  return (
                    <button
                      key={dateStr}
                      onClick={() => setSelectedDate(dateStr)}
                      className={`px-4 py-2.5 rounded-2xl text-center transition-all shrink-0 ${
                        isSelected
                          ? 'bg-fuchsia-600 text-white shadow-lg shadow-fuchsia-600/30'
                          : 'bg-slate-900/90 text-slate-300 hover:bg-slate-800 border border-slate-800'
                      }`}
                    >
                      <span className="text-[10px] uppercase font-bold block opacity-80">{dayName}</span>
                      <span className="text-xs font-extrabold block">{monthDay}</span>
                    </button>
                  );
                })}
              </div>
            ) : (
              <p className="text-xs text-slate-400">No scheduled shows for this event currently.</p>
            )}

            {/* Show Slots for Selected Date */}
            <div className="space-y-3 pt-2">
              {filteredShows.length > 0 ? (
                filteredShows.map((shw) => (
                  <div
                    key={shw._id}
                    className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-base font-extrabold text-white">{shw.startTime}</span>
                        <span className="text-xs text-slate-400">to {shw.endTime}</span>
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          {shw.availableSeats} Seats Available
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 mt-1">{shw.screenName}</p>

                      {/* Pricing pills */}
                      <div className="flex flex-wrap gap-2 mt-2">
                        {shw.pricingTiers?.map((pt, pIdx) => (
                          <span key={pIdx} className="text-[10px] text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                            {pt.tier}: <strong className="text-slate-200">₹{pt.price}</strong>
                          </span>
                        ))}
                      </div>
                    </div>

                    <Link
                      to={`/book/${shw._id}`}
                      className="px-5 py-2.5 rounded-xl font-bold text-xs bg-fuchsia-600 hover:bg-fuchsia-500 text-white shadow-lg shadow-fuchsia-600/30 text-center flex items-center justify-center gap-1.5 transition-all"
                    >
                      <Ticket className="w-3.5 h-3.5" />
                      <span>Select Seats</span>
                    </Link>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-400 py-4">No shows available for the selected date.</p>
              )}
            </div>
          </div>

          {/* Performer / Cast list */}
          {event.cast && event.cast.length > 0 && (
            <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-fuchsia-400" />
                <span>Headliners & Cast</span>
              </h3>
              <div className="flex flex-wrap gap-2">
                {event.cast.map((performer, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-semibold text-slate-200"
                  >
                    <div className="w-6 h-6 rounded-full bg-fuchsia-600/30 text-fuchsia-300 flex items-center justify-center text-[10px] font-bold">
                      {performer.charAt(0)}
                    </div>
                    <span>{performer}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* User Reviews */}
          <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-fuchsia-400" />
              <span>Verified Audience Reviews ({reviews.length})</span>
            </h3>

            <div className="space-y-3">
              {reviews.map((rev) => (
                <div key={rev._id} className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <img src={rev.userAvatar} alt={rev.userName} className="w-7 h-7 rounded-full bg-slate-800" />
                      <span className="text-xs font-bold text-slate-200">{rev.userName}</span>
                    </div>
                    <div className="flex items-center gap-0.5 text-yellow-400 text-xs font-bold">
                      <Star className="w-3.5 h-3.5 fill-yellow-400" />
                      <span>{rev.rating}.0</span>
                    </div>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">{rev.comment}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Venue, Ground Rules & Cancellation Guarantee */}
        <div className="space-y-6">
          {/* Venue Card */}
          <div className="glass-panel p-6 rounded-3xl border border-slate-800 space-y-4">
            <h3 className="text-base font-bold text-white">Venue Location</h3>
            <div>
              <p className="font-bold text-sm text-fuchsia-300">{event.venueName}</p>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">{event.address}</p>
            </div>
            <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-1">
              <span className="font-bold text-slate-200 block">Accessibility & Entry</span>
              <p className="text-[11px] text-slate-400">Wheelchair ramps & accessible companion seating certified.</p>
            </div>
          </div>

          {/* Refund & Booking Guarantee Callout */}
          <div className="p-6 rounded-3xl bg-gradient-to-b from-fuchsia-950/40 to-slate-900/60 border border-fuchsia-500/30 space-y-4">
            <div className="flex items-center gap-2 text-fuchsia-300 font-bold text-sm">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <span>Venuro Assured Booking</span>
            </div>
            <ul className="space-y-2 text-xs text-slate-300">
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">✓</span>
                <span><strong>5-Min Redis Lock:</strong> Your seats are guaranteed exclusively while checking out.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">✓</span>
                <span><strong>100% Refund:</strong> Cancel &gt;24 hrs prior for instant wallet refund.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">✓</span>
                <span><strong>Tamper-Proof QR:</strong> Fast paperless entry at the gate.</span>
              </li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};
