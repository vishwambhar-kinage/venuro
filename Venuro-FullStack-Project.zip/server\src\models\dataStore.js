import { randomUUID } from 'crypto';

/**
 * Universal Unified Data Store for Venuro
 * Holds collections for Users, Events, Shows, Bookings, Reviews, and KnowledgeBase items.
 * Allows synchronous and asynchronous querying with MongoDB-like interfaces.
 */

class UniversalDataStore {
  constructor() {
    this.users = [];
    this.events = [];
    this.shows = [];
    this.bookings = [];
    this.reviews = [];
    this.knowledgeBase = [];
    this.initialized = false;
  }

  // Users collection methods
  findUserById(id) {
    return this.users.find(u => u._id === id || u.id === id);
  }

  findUserByEmail(email) {
    if (!email) return null;
    return this.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  createUser(userData) {
    const user = {
      _id: userData._id || `usr_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      name: userData.name,
      email: userData.email.toLowerCase(),
      password: userData.password,
      role: userData.role || 'user', // 'user' | 'coordinator' | 'admin'
      avatar: userData.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(userData.name)}`,
      walletBalance: userData.walletBalance !== undefined ? userData.walletBalance : 1000,
      preferences: userData.preferences || ['Concerts', 'Movies'],
      createdAt: new Date().toISOString()
    };
    this.users.push(user);
    return user;
  }

  // Events collection methods
  getAllEvents(filter = {}) {
    let result = [...this.events];
    if (filter.category && filter.category !== 'all') {
      result = result.filter(e => e.category.toLowerCase() === filter.category.toLowerCase());
    }
    if (filter.city && filter.city !== 'all') {
      result = result.filter(e => e.city.toLowerCase() === filter.city.toLowerCase());
    }
    if (filter.search) {
      const q = filter.search.toLowerCase();
      result = result.filter(e =>
        e.title.toLowerCase().includes(q) ||
        e.description.toLowerCase().includes(q) ||
        e.genre.some(g => g.toLowerCase().includes(q)) ||
        e.venueName.toLowerCase().includes(q)
      );
    }
    if (filter.status) {
      result = result.filter(e => e.status === filter.status);
    }
    return result;
  }

  findEventById(id) {
    return this.events.find(e => e._id === id || e.id === id);
  }

  createEvent(eventData) {
    const newEvent = {
      _id: eventData._id || `evt_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      title: eventData.title,
      slug: eventData.slug || eventData.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      category: eventData.category, // 'movies' | 'concerts' | 'sports' | 'live-shows' | 'experiences'
      description: eventData.description,
      bannerUrl: eventData.bannerUrl || 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=1200',
      posterUrl: eventData.posterUrl || 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=600',
      city: eventData.city || 'Mumbai',
      venueName: eventData.venueName || 'Venuro Grand Arena',
      address: eventData.address || 'BKC, Mumbai, Maharashtra 400051',
      duration: eventData.duration || '2h 30m',
      language: eventData.language || 'English / Hindi',
      genre: eventData.genre || ['Entertainment', 'Live'],
      ageLimit: eventData.ageLimit || '13+',
      cast: eventData.cast || [],
      rating: eventData.rating || 4.8,
      totalReviews: eventData.totalReviews || 120,
      status: eventData.status || 'active', // 'active' | 'pending' | 'draft'
      coordinatorId: eventData.coordinatorId || 'usr_coord_1',
      vectorEmbedding: eventData.vectorEmbedding || [],
      createdAt: new Date().toISOString()
    };
    this.events.unshift(newEvent);
    return newEvent;
  }

  updateEvent(id, updates) {
    const idx = this.events.findIndex(e => e._id === id || e.id === id);
    if (idx === -1) return null;
    this.events[idx] = { ...this.events[idx], ...updates, updatedAt: new Date().toISOString() };
    return this.events[idx];
  }

  deleteEvent(id) {
    const idx = this.events.findIndex(e => e._id === id || e.id === id);
    if (idx === -1) return false;
    this.events.splice(idx, 1);
    return true;
  }

  // Shows collection methods
  getShowsForEvent(eventId) {
    return this.shows.filter(s => s.eventId === eventId);
  }

  findShowById(id) {
    return this.shows.find(s => s._id === id || s.id === id);
  }

  createShow(showData) {
    const newShow = {
      _id: showData._id || `shw_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      eventId: showData.eventId,
      screenName: showData.screenName || 'Audi 1 - Dolby Atmos 4K',
      date: showData.date, // 'YYYY-MM-DD'
      startTime: showData.startTime, // '19:30'
      endTime: showData.endTime || '22:00',
      pricingTiers: showData.pricingTiers || [
        { tier: 'VIP', price: 1500, rows: ['A', 'B'] },
        { tier: 'PREMIUM', price: 900, rows: ['C', 'D', 'E'] },
        { tier: 'STANDARD', price: 500, rows: ['F', 'G', 'H', 'I'] },
        { tier: 'ECONOMY', price: 250, rows: ['J', 'K'] }
      ],
      seatGrid: showData.seatGrid || this._generateDefaultSeatGrid(showData.pricingTiers),
      totalSeats: showData.totalSeats || 120,
      availableSeats: showData.availableSeats || 120,
      createdAt: new Date().toISOString()
    };
    this.shows.push(newShow);
    return newShow;
  }

  _generateDefaultSeatGrid(customTiers) {
    const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K'];
    const cols = 12;
    const grid = [];

    const getTierFor = (rowLetter) => {
      if (['A', 'B'].includes(rowLetter)) return { tier: 'VIP', price: 1500 };
      if (['C', 'D', 'E'].includes(rowLetter)) return { tier: 'PREMIUM', price: 900 };
      if (['F', 'G', 'H', 'I'].includes(rowLetter)) return { tier: 'STANDARD', price: 500 };
      return { tier: 'ECONOMY', price: 250 };
    };

    rows.forEach(rowLetter => {
      const rowSeats = [];
      const tierInfo = getTierFor(rowLetter);
      for (let c = 1; c <= cols; c++) {
        // Randomly simulate a few already booked seats for realism
        const isPrebooked = Math.random() < 0.15;
        rowSeats.push({
          id: `${rowLetter}${c}`,
          row: rowLetter,
          col: c,
          tier: tierInfo.tier,
          price: tierInfo.price,
          status: isPrebooked ? 'booked' : 'available'
        });
      }
      grid.push(rowSeats);
    });

    return grid;
  }

  // Bookings collection methods
  createBooking(bookingData) {
    const newBooking = {
      _id: bookingData._id || `bkg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      bookingNumber: bookingData.bookingNumber || `VNR-${Date.now().toString().slice(-6)}-${Math.floor(1000 + Math.random() * 9000)}`,
      userId: bookingData.userId,
      eventId: bookingData.eventId,
      showId: bookingData.showId,
      seats: bookingData.seats || [],
      totalAmount: bookingData.totalAmount,
      convenienceFee: bookingData.convenienceFee || 40,
      discountAmount: bookingData.discountAmount || 0,
      finalAmount: bookingData.finalAmount,
      paymentDetails: bookingData.paymentDetails || {
        paymentId: `PAY_${Date.now()}_${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
        method: 'UPI',
        status: 'SUCCESS',
        timestamp: new Date().toISOString()
      },
      bookingStatus: 'CONFIRMED', // 'CONFIRMED' | 'CANCELLED' | 'REFUNDED'
      qrCodeData: bookingData.qrCodeData,
      qrCodeImage: bookingData.qrCodeImage,
      refundAmount: 0,
      cancellationReason: '',
      createdAt: new Date().toISOString()
    };
    this.bookings.unshift(newBooking);
    return newBooking;
  }

  findBookingById(id) {
    return this.bookings.find(b => b._id === id || b.bookingNumber === id);
  }

  getBookingsForUser(userId) {
    return this.bookings.filter(b => b.userId === userId);
  }

  getAllBookings() {
    return this.bookings;
  }

  cancelBooking(id, reason = 'User requested cancellation', refundAmount = 0) {
    const booking = this.findBookingById(id);
    if (!booking) return null;
    booking.bookingStatus = 'CANCELLED';
    booking.cancellationReason = reason;
    booking.refundAmount = refundAmount;
    booking.cancelledAt = new Date().toISOString();
    return booking;
  }

  // Reviews collection
  createReview(reviewData) {
    const review = {
      _id: `rev_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      userId: reviewData.userId,
      userName: reviewData.userName || 'Anonymous',
      userAvatar: reviewData.userAvatar || 'https://api.dicebear.com/7.x/avataaars/svg?seed=user',
      eventId: reviewData.eventId,
      rating: reviewData.rating || 5,
      comment: reviewData.comment || '',
      createdAt: new Date().toISOString()
    };
    this.reviews.unshift(review);
    return review;
  }

  getReviewsForEvent(eventId) {
    return this.reviews.filter(r => r.eventId === eventId);
  }
}

export const dataStore = new UniversalDataStore();
